for x in range(0x4001, 0x4001 + 1023):
	print('%COMPOSITE%  =USB_Install,  USB\VID_1209&PID_' + "{0:0{1}X}".format(x,4) + '&MI_01')