#include "SPI.h"
#include "mstn_spi.h"

_BitOrder SPIClass::bitOrder = MSBFIRST;
int SPIClass::clkDivider = 1;

void SPIClass::begin() {
    SPI_Begin(SPI1, SPI_MODE0, SPI_WL8, 1);
}

void SPIClass::end() {
  SPI_End(SPI1);
}

void SPIClass::setBitOrder(uint8_t bitOrder)
{
  if(bitOrder == LSBFIRST) {
    SPIClass::bitOrder = LSBFIRST;
  } else {
    SPIClass::bitOrder = MSBFIRST;
  }
}

void SPIClass::setDataMode(uint8_t mode)
{
    SPI_Begin(SPI1, (_SPI_Mode)mode, SPI_WL8, SPIClass::clkDivider);
}

void SPIClass::setClockDivider(uint8_t rate)
{
    int clkDiv = 1;
    switch(rate)
    {
        case SPI_CLOCK_DIV128:
            clkDiv*= 2;
        case SPI_CLOCK_DIV64:
            clkDiv*= 2;
        case SPI_CLOCK_DIV32:
            clkDiv*= 2;
        case SPI_CLOCK_DIV16:
            clkDiv*= 2;
        case SPI_CLOCK_DIV8:
            clkDiv*= 2;
        case SPI_CLOCK_DIV4:
            clkDiv*= 2;
        case SPI_CLOCK_DIV2:
            clkDiv*= 2;
            break;
        default:
        return;
    }
    SPIClass::clkDivider = clkDiv;
    SPI_SetClockDivider(SPI1, clkDiv);
}

byte SPIClass::transfer(byte _data) {
    if (SPIClass::bitOrder == LSBFIRST)
    {
        int base = 256;
        unsigned char  res = 0;
        while (_data != 0) 
        {
            res += (_data & 1) * (base >>= 1);
            _data >>= 1;
        }
        byte shiftedIn = (byte)SPI_Transfer(SPI1, (short int)res);
        base = 256;
        res = 0;
        while (shiftedIn != 0) 
        {
            res += (shiftedIn & 1) * (base >>= 1);
            shiftedIn >>= 1;
        }
        return (byte)res;
    }
    return (byte)SPI_Transfer(SPI1, (short int)_data);
}

void SPIClass::attachInterrupt() {
  ;
}

void SPIClass::detachInterrupt() {
  ;
}