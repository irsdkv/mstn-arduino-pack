/*!
  * \file    mstn_external_interrupt.h
  * \author  Intec Group
  * \version V2.0.0
  * \date    17/10/2016
  * \brief   This file contains all the required functions prototypes for the MSTN EXT INT firmware library.
  *
  * \warning THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, INTEC SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * \copyright COPYRIGHT 2017 Intec Group
  */

#ifndef __mstn_external_interrupt_h
#define __mstn_external_interrupt_h

#ifdef __cplusplus
extern "C" {
#endif

typedef enum{
    RISING = 0,     // Нисходящий фронт.
    FALLING = 1,    // Нарастающий фронт.
    CHANGE = 2,     // Нарастающий фронт.
}_Edge;

/*!
 * \brief   Задает функцию обработки внешнего прерывания, то есть функцию, 
 *          которая будет вызвана по внешнему прерыванию. 
 * \details Если до это была задана другая функция, то назначается новая.
 *          Приоритет прерывания устанавливается равным 3.
 *          Приоритеты прерываний внутри группы внешних прерываний: 
 *          Прерывание на вывод D6 обрабатывается первым, далее следуют прерывания
 *          от выводов D4, D7, D8, D9 в порядке убывания приоритета.
 * \param   isr - функция, вызываемая прерыванием, функция должна быть без параметров и не возвращать значений.
 * \param   pinNum - номер вывода порта DIGITAL. Может принимать следующие значения: D1, D4, D6, D7, D8, D9.
 * \param   edge - фронт, при котором вызывается прерывание. Может принимать следующие значения:
 *                  \arg RISING
 *                  \arg FALLING
 *                  \arg CHANGE - вызов прерывания при смене логического уровня сигнала.
 * \retval  Нет
 */
void EINT_AttachExtInt(void (*isr)(), uint8_t pinNum, _Edge edge);

/*!
 * \brief   Отключает прерывание на заданном выводе. Вывод переводится в режим DIGITAL_INPUT.
 * \param   pinNum - номер пина порта DIGITAL.
 * \retval  Нет
 */
void EINT_DetachExtInt(uint8_t pinNum);

#ifdef __cplusplus
}
#endif

#endif /* __mstn_external_interrupt_h */

