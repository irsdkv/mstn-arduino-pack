/*!
  * \file    mstn_usb_descriptors_composite.h
  * \author  Intec Group
  * \version V2.0.0
  * \date    17/02/2017
  * \brief   This file contains all the required descriptors for the user-mode USB firmware library.
  *
  * \warning THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, INTEC SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * \copyright COPYRIGHT 2017 Intec
  */

#ifndef __mstn_usb_descriptors_composite_h
#define __mstn_usb_descriptors_composite_h

#define OS_VENDOR_CODE              0xAE
#define MSTN_REQUEST                0x17
#define MSTN_SET_USER_TRANS_STATE   0x3
#define USER_TRANS_FORBID_VAL       0x0
#define USER_TRANS_PERMIT_VAL       0x1
#define BCD_VERSION_100             0x0100
#define BCD_VERSION_200             0x0200
#define VID_NUM                     0x1209 ///< pid.codes VendorID - free VID 
#define PID_NUM                     0x0009 ///< pid.codes Test PID
#define DEVICE_VER                  0x0040

enum USB_DESCRIPTOR_TYPES {
    USB_DEVICE_DESCRIPTOR_TYPE = 0x01, ///< Стандартный дескриптор устройства
    USB_CONFIGURATION_DESCRIPTOR_TYPE = 0x02, ///< Дескриптор конфигурации
    USB_STRING_DESCRIPTOR_TYPE = 0x03, ///< Дескриптор строки
    USB_INTERFACE_DESCRIPTOR_TYPE = 0x04, ///< Дескриптор интерфейса
    USB_ENDPOINT_DESCRIPTOR_TYPE = 0x05, ///< Дескриптор конечной точки
    DEVICE_QUALIFIER = 0x06, ///< Уточняющий дескриптор устройства
    OTHER_SPEED_CONFIGURATION = 0x07, ///< Дескриптор дополнительной конфигурации
    INTERFACE_POWER = 0x08, ///< Дескриптор управления питанием интерфейса
    OTG = 0x09, ///< Дескриптор OTG
    DEBUG = 0x0A, ///< Отладочный дескриптор
    INTERFACE_ASSOCIATION = 0x0B, ///< Дополнительный дескриптор интерфейса
    USB_GET_MS_DESCRIPTOR = OS_VENDOR_CODE ///< Дескриптор OS feature
	
};

enum OS_FEATURE_DESCRIPTORS_INDEXES {
    GENRE = 0x0001,
    EXTENDED_COMPAT_ID = 0x0004,
    EXTENDED_PROPERTIES = 0x0005
};

enum {
    RESERVED = 0,
    REG_SZ = 1, ///< A NULL-terminated Unicode String
    REG_EXPAND_SZ = 2, ///< A NULL-terminated Unicode String that includes environment variables
    REG_BINARY = 3, ///< Free-form binary
    REG_DWORD_LITTLE_ENDIAN = 4, ///< A little-endian 32-bit integer
    REG_DWORD_BIG_ENDIAN = 5, ///< A big-endian 32-bit integer
    REG_LINK = 6, ///< A NULL-terminated Unicode string that contains a symbolic link
    REG_MULTI_SZ = 7 ///< Multiple NULL-terminated Unicode strings
} _propertyTypes;

enum STRING_DESCRYPROR_NUMS {
    LANG_ID_DESCR_STRING_NUM = 0x00,
    MANUFACTURER_DESCR_STRING_NUM = 0x01,
    PRODUCT_DESCR_STRING_NUM = 0x02,
    SERIAL_NUMBER_DESCR_STRING_NUM = 0x03,
    CONFIGURATION_DESCR_STRING_NUM = 0x04,
    INTERFACE_WINUSB_DESCR_STRING_NUM = 0x5,
    INTERFACE_DATA_DESCR_STRING_NUM = 0x06,
    MICROSOFT_OS_STRING_DESCR_STRING_NUM = 0xEE
};

typedef enum {
    CONTROL = 0x00,
    ISOCHRONOUS = 0x01,
    BULK = 0x02,
    INTERRUPT = 0x03
} _TransactTypes;

typedef enum {
    EP_DIRECTION_OUT = (0 << 7),
    EP_DIRECTION_IN = (1 << 7)
} _TransDirection;

typedef enum {
    USB_TYPE_STANDARD = 0x0,
    USB_TYPE_CLASS = 0x20,
    USB_TYPE_VENDOR = 0x40,
} _RequestType;

typedef enum {
    USB_RECIPIENT_DEVICE = 0x0,
    USB_RECIPIENT_INTERFACE = 0x1,
    USB_RECIPIENT_ENDPOINT = 0x2,
    USB_RECIPIENT_OTHER = 0x3
} _RequestRecipient;

typedef enum {
    USB_GET_STATUS = 0,
    USB_CLEAR_FEATURE, ///< 1
    USB_Reserved0, ///< 2
    USB_SET_FEATURE, ///< 3
    USB_Reserved1, ///< 4
    USB_SET_ADDRESS, ///< 5
    USB_GET_DESCRIPTOR, ///< 6
    USB_SET_DESCRIPTOR, ///< 7
    USB_GET_CONFIGURATION, ///< 8
    USB_SET_CONFIGURATION, ///< 9
    USB_GET_INTERFACE, ///< 10
    USB_SET_INTERFACE, ///< 11
    USB_SYNCH_FRAME, ///< 12
} _USB_Standard_Setup; ///< 13

typedef enum
{
  USB_CDC_SEND_ENCAPSULATED_COMMAND = 0x00,
  USB_CDC_GET_ENCAPSULATED_RESPONSE,
  USB_CDC_SET_COMM_FEATURE,
  USB_CDC_GET_COMM_FEATURE,
  USB_CDC_CLEAR_COMM_FEATURE,
  USB_CDC_SET_AUX_LINE_STATE        = 0x10,
  USB_CDC_SET_HOOK_STATE,
  USB_CDC_PULSE_SETUP,
  USB_CDC_SEND_PULSE,
  USB_CDC_SET_PULSE_TIME,
  USB_CDC_RING_AUX_JACK,
  USB_CDC_SET_LINE_CODING           = 0x20,
  USB_CDC_GET_LINE_CODING,
  USB_CDC_SET_CONTROL_LINE_STATE,
  USB_CDC_SEND_BREAK,
  USB_CDC_SET_RINGER_PARAMS         = 0x30,
  USB_CDC_GET_RINGER_PARAMS,
  USB_CDC_SET_OPERATION_PARAMS,
  USB_CDC_GET_OPERATION_PARAMS,
  USB_CDC_SET_LINE_PARAMS,
  USB_CDC_GET_LINE_PARAMS,
  USB_CDC_DIAL_DIGITS
} USB_CDC_Class_Setup_TypeDef;

typedef enum
{
  USB_CDC_bRxCarrier  = 0x01,
  USB_CDC_bTxCarrier  = 0x02,
  USB_CDC_bBreak      = 0x04,
  USB_CDC_bRingSignal = 0x08,
  USB_CDC_bFraming    = 0x10,
  USB_CDC_bParity     = 0x20,
  USB_CDC_bOverRun    = 0x40
}USB_CDCSerialState_TypeDef;

typedef enum
{
  USB_CDC_STOP_BITS1   = 0x0,
  USB_CDC_STOP_BITS1_5 = 0x1,
  USB_CDC_STOP_BITS2   = 0x2,
}USB_CDC_CharFormat_TypeDef;

typedef enum
{
  USB_CDC_PARITY_NONE  = 0x0,
  USB_CDC_PARITY_ODD   = 0x1,
  USB_CDC_PARITY_EVEN  = 0x2,
  USB_CDC_PARITY_MARK  = 0x3,
  USB_CDC_PARITY_SPACE = 0x4
}USB_CDC_ParityType_TypeDef;

typedef enum
{
  USB_CDC_DATA_BITS5  = 0x5,
  USB_CDC_DATA_BITS6  = 0x6,
  USB_CDC_DATA_BITS7  = 0x7,
  USB_CDC_DATA_BITS8  = 0x8,
  USB_CDC_DATA_BITS16 = 0xA
}USB_CDC_DataBits_TypeDef;


typedef enum
{
  USB_CDC_DTR_PRESENT          = 0x1,
  USB_CDC_RTS_ACTIVATE_CARRIER = 0x2
}USB_CDC_ControlLineState_TypeDef;

typedef enum
{
  USB_CDC_RING_DETECT             = 0x09,
  USB_CDC_SERIAL_STATE            = 0x20,
  USB_CDC_CALL_STATE_CHANGE       = 0x28,
  USB_CDC_LINE_STATE_CHANGE       = 0x29,
  USB_CDC_CONNECTION_SPEED_CHANGE = 0x2A
}USB_CDC_LineStateReport_TypeDef;


typedef enum {
    SETUP_STAGE,
    DATA_STAGE,
    STATUS_STAGE,
} _ControlTransactionStages;

enum {
    INTERFACE_WINUSB_CONTROL = 0x0,
    INTERFACE_WINUSB_IO = 0x1,
    INTERFACE_DATA = 0x2,
};

enum LANGUAGES_IDs {
    LANG_ID_ENGLISH = 0x0409,
    LANG_ID_RUSSIAN = 0x0419
};

#pragma pack(push, 1)

typedef struct {
    unsigned char bLength; ///< Размер дескриптора в байтах (Длина строки + 2)
    unsigned char bDescriptorType; ///< Тип дескриптора (USB_STRING_DESCRIPTOR_TYPE)
    unsigned char qwSignature[14]; ///< Signature field
    unsigned char bMS_VendorCode; ///< Vendor code
    unsigned char bPad; ///< Pad field, Value = const(0x00)
} _USB_STRING_OS_DESCRIPTOR;

typedef struct {
    unsigned int dwLength; ///< The length, in bytes, of the complete extended compat ID descriptor
    unsigned short bcdVersion; ///< The descriptor’s version number, in binary coded decimal (BCD) format. For version 1.00, bcdVersion is set to 0x0100
    unsigned short wIndex; ///< An index that identifies the particular OS feature descriptor. Equal EXTENDED_COMPAT_ID
    unsigned char bCount; ///< The number of function sections. This value, combined with dwLength, allows Windows to parse the descriptor.
    unsigned char bReservedField[7]; ///< Reserved
} _EXTENDED_COMPAT_ID_OS_FEATURE_DESCR_HEADER_SECTION;

typedef struct {
    unsigned char bFirstInterfaceNumber; ///< The interface or function number
    unsigned char bReserved; ///< Reserved for system use. Set this value to 0x01.
    unsigned char compatibleID[8]; ///< The function’s compatible ID
    unsigned char subCompatibleID[8]; ///< The function’s subcompatible ID
    unsigned char bReservedField[6]; ///< Reserved. Fill this value with NULLs.
} _EXTENDED_COMPAT_ID_OS_FEATURE_DESCR_FUNCTION_SECTION;

#define WPROPERTYNAMELENGTH  10
#define WPROPERTYDATALENGTH  4

typedef struct {
    unsigned int dwLength; ///< The length, in bytes, of the complete extended properties descriptor
    unsigned short bcdVersion; ///< The descriptor’s version number, in binary coded decimal (BCD) format For version 1.00, bcdVersion is set to 0x0100
    unsigned short wIndex; ///< The index for extended properties OS descriptors. Equal EXTENDED_COMPAT_ID
    unsigned short wCount; ///< The number of custom property sections that follow the header section
} _EXTENDED_PROPERTY_OS_FEATURE_DESCR_HEADER;

//#define PROP_NAME_LEN_LABEL 0x000C
//#define PROP_DATA_LEN_LABEL 0x00000016

/* OS Extended Properties Descriptor */
//typedef struct {
//    unsigned int dwSize;
//    unsigned int dwPropertyDataType;
//    unsigned short wPropertyNameLength;
//    unsigned char bPropertyName[PROP_NAME_LEN_LABEL];
//    unsigned int dwPropertyDataLength;
//    unsigned char bPropertyData[PROP_DATA_LEN_LABEL];
//} _EXTENDED_PROPERTY_OS_FEATURE_DESCR_PROPERTY_LABEL;

typedef struct {
    unsigned char bLength; ///< Размер дескриптора в байтах
    unsigned char bDescriptorType; ///< Тип дескриптора (USB_DEVICE_DESCRIPTOR_TYPE)
    unsigned short bcdUSB; ///< Номер версии спецификации USB в формате BCD
    unsigned char bDeviceClass; ///< Код класса USB
    unsigned char bDeviceSubClass; ///< Код подкласса устройства
    unsigned char bDeviceProtocol; ///< Код протокола USB
    unsigned char bMaxPacketSize0; ///< Максимальный размер пакета для нулевой конечной точки
    unsigned short idVendor; ///< Идентификатор изготовителя устройства
    unsigned short idProdict; ///< Идентификатор продукта
    unsigned short bcdDevice; ///< Номер версии устройства в формате BCD
    unsigned char iManufacturer; ///< Индекс дескриптора строки, описывающей изготовителя
    unsigned char iProduct; ///< Индекс дескриптора строки, описывающей продукт
    unsigned char iSerialNumber; ///< Индекс дескриптора строки, содержащий серийный номер устройства
    unsigned char bNumConfigurations; ///< Количество возможных конфигураций устройства
} _USB_DEVICE_DESCRIPTOR;

typedef struct {
    unsigned char bLength;
    unsigned char bDescriptorType;
    unsigned short bcdUSB;
    unsigned char bDeviceClass;
    unsigned char bDeviceSubClass;
    unsigned char bDeviceProtocol;
    unsigned char bMaxPacketSize0;
    unsigned char bNumConfigurations;
    unsigned char bReserved;
} _USB_DEVICE_QUALIFIER_DESCRIPTOR;

typedef struct {
    unsigned char bLength; ///< Размер дескриптора в байтах
    unsigned char bDescriptorType; ///< Тип дескриптора (USB_CONFIGURATION_DESCRIPTOR_TYPE)
    unsigned short wTotalLength; ///< Общий объем данных (в байтах), возвращаемый для данной конфигурации
    unsigned char bNumInterfaces; ///< Количество интерфейсов, поддерживаемых данной конфигурацией
    unsigned char bConfigurationValue; ///< Идентификатор конфигурации, используемый при вызове SET_CONFIGURATION для установки данной конфигурации
    unsigned char iConfiguration; ///< Индекс дескриптора строки, описывающей данную конфигурацию 
    unsigned char bmAttributes; /*!< Характеристики мощности конфигурации. 
											Битовое поле: 
											\arg  D7 Зарезервирован, равен 0 (USB1.0 Bus Powered)
											\arg  D6 Питание от шины - 0, собственный источник питания - 1
											\arg  D5 Возможность пробуждения устройства по внешнему сигналу: 0 - нет такой возможности, 1 - имеется такая возможность
											\arg  D4..0 Зарезервированы, равны 0 */
    unsigned char MaxPower; ///< Максимальный ток в миллиамперах, потребляемый устройством, деленный на 2
} _USB_CONFIGURATION_DESCRIPTOR;

typedef struct {
    unsigned char bLength; ///< Размер дескриптора в байтах
    unsigned char bDescriptorType; ///< Тип дескриптора (USB_INTERFACE_DESCRIPTOR_TYPE)
    unsigned char bInterfaceNumber; ///< Номер данного интерфейса (нумеруются с 0) в наборе интерфейсов, поддерживаемых в данной конфигурации
    unsigned char bAlternateSetting; ///< Альтернативный номер интерфейса
    unsigned char bNumEndpoints; ///< Число конечных точек для этого интерфейса без учета нулевой конечной точки
    unsigned char bInterfaceClass; ///< Код класса интерфейса
    unsigned char bInterfaceSubClass; ///< Код подкласса интерфейса
    unsigned char bInterfaceProtocol; ///< Код протокола
    unsigned char iInterface; ///< Индекс дескриптора строки, описывающей интерфейс
} _USB_INTERFACE_DESCRIPTOR;

typedef struct {
    unsigned char bLength; ///< Размер дескриптора в байтах
    unsigned char bDescriptorType; ///< Тип дескриптора (USB_ENDPOINT_DESCRIPTOR_TYPE)
    unsigned char bEndpoinAddress; /*!< Код адреса конечной точки:
										\arg  D7 Направление передачи: От хоста (OUT) - 0, к хосту (IN) - 1
										\arg  D6..4 Зарезервированы, содержит нули
										\arg  D3..0 Номер конечной точки */
    unsigned char bmAttributes; /*!< Атрибуты конечной точки:
										\arg  D7..6 Зарезервированы, равны нулю
										\arg  D5..4 Тип использования конечной точки (для изохорных каналов):
										\arg  00 - конечная точка (данные) Data
										\arg  01 - конечная точка для явной обратной связи Feedback
										\arg  10 - конечная точка неявной обратной связи Implicit feedback
										\arg  11 - зарезервирвоано Reserved
										\arg  D3..2 Тип синхронизации (для изохорных каналов):
										\arg  00 - нет синхронизации
										\arg  01 - асинхронная
										\arg  10 - адаптивная
										\arg  11 - синхронная 
										\arg  D1..0 Тип конечной точки:
										\arg  00 - канал сообщений Control
										\arg  01 - изохорный канал Isochronous
										\arg  10 - канал передачи данных Bulk
										\arg  11 - канал прерываний Interrupt */
    unsigned short wMaxPacketSize; ///< Максимальный размер пакета для конечной точки
    unsigned char bInterval; /*!< Интервал опроса конечной точки при передаче данных (в миллисекундах)
										\arg  Имеет значение только в случае, если точка используется для передачи данных по прерываниям.
										\arg  Для изохронных точек всегда равен 1.
										\arg  Для остальных типов конечных точек значение игнорируется */
} _USB_ENDPOINT_DESCRIPTOR;

typedef struct {
    unsigned short SelfPowered_RemoteWakeup_Reserved;
} _USB_GET_STATUS_ANSWER;

#define MAX_LENGT_DESCRIPTOR_STRING  30

typedef struct {
    unsigned char bLength; ///< Размер дескриптора в байтах (Длина строки + 2)
    unsigned char bDescriptorType; ///< Тип дескриптора (USB_STRING_DESCRIPTOR_TYPE)
    unsigned short wString[MAX_LENGT_DESCRIPTOR_STRING]; ///< Строка символов UNICODE
} _USB_STRING_DESCRIPTOR;

#define SETUP_PACKET_MAX_DATA_LENGTH    8

typedef struct {
    unsigned char mRequestType; /*!< Characteristics of request:
                                              \arg  D7:    Data transfer direction (USB_RequestTypeDT_TypeDef),
                                              \arg  D6..5: Type (USB_RequestType_TypeDef),
                                              \arg  D4..0: Recipient (USB_RequestRecipient_TypeDef). */
    unsigned char bRequest; /*!< Specific request. */
    unsigned short wValue; /*!< Request value 1st word (wValue). */
    unsigned short wIndex; /*!< Request value 2nd word (wIndex). */
    unsigned short wLength; /*!< Data stage bytes number. */
    unsigned char data[SETUP_PACKET_MAX_DATA_LENGTH]; /*!< Data stage bytes number. */
} _SetupPacketStructure;

#pragma pack(pop)


#define EP_ADDRESS_0 (0<<0)
#define EP_ADDRESS_1 (1<<0)
#define EP_ADDRESS_2 (1<<1)
#define EP_ADDRESS_3 (1<<1 | 1<<0)
#define EP_PACKSIZE_64 0x40
#define CONFIGURATION_DESCRIPTOR_LEN  9
#define INTERFACE_DESCRIPTOR_LEN   9
#define NUM_OF_INTERFACES     4
#define ENDPOINT_DESCRIPTOR_LEN    7
#define ENDPOINT_NUM_IN_EACH_INTERFACE  4

#define PROP_NAME_LEN_GUID      0x28
#define PROP_DATA_LEN_GUID      0x4E

#define PROP_NAME_LEN_LABEL     0x0C
#define PROP_DATA_LEN_LABEL     0x0C

#define NUM_INTERFACES_IN_CONFIG  1
//unsigned char GUID[32] = {8b6173c6-7100-45a1-b278-982adaa050c6}
#define CUSTOM_PROPERTY_SECTION_GUID_LENGTH         0x00000084
//#define CUSTOM_PROPERTY_SECTION_LABEL_LENGTH        0x00000026

#define CUSTOM_PROPERTY_SECTIONS_LENGTH             (CUSTOM_PROPERTY_SECTION_GUID_LENGTH)

const unsigned int dwSize_GUID = CUSTOM_PROPERTY_SECTION_GUID_LENGTH;
const unsigned int dwPropertyDataType_GUID = REG_SZ;
const unsigned short wPropertyNameLength_GUID = PROP_NAME_LEN_GUID;
const unsigned short bPropertyName_GUID[PROP_NAME_LEN_GUID / 2] = {'D', 'e', 'v', 'i', 'c', 'e', 'I', 'n', 't', 'e', 'r', 'f', 'a', 'c', 'e', 'G', 'U', 'I', 'D', 0};
const unsigned int dwPropertyDataLength_GUID = PROP_DATA_LEN_GUID;
const unsigned short bPropertyData_CTRL_GUID[PROP_DATA_LEN_GUID / 2] = {'{', '8', 'b', '6', '1', '7', '3', 'c', '6', '-', '7', '1', '0', '0', '-', '4', '5', 'a', '1', '-', 'b', '2', '7', '8', '-', '9', '8', '2', 'a', 'd', 'a', 'a', '0', '5', '0', 'c', '6', '}', 0};
const unsigned short bPropertyData_IO_GUID[PROP_DATA_LEN_GUID / 2] = {'{', '8', 'b', '7', '1', '7', '3', 'c', '6', '-', '7', '1', '0', '0', '-', '4', '5', 'a', '1', '-', 'b', '2', '7', '8', '-', '9', '8', '2', 'a', 'd', 'a', 'a', '0', '5', '0', 'c', '7', '}', 0};


//const unsigned int dwSize_Label = CUSTOM_PROPERTY_SECTION_LABEL_LENGTH;
//const unsigned int dwPropertyDataType_Label = REG_SZ;
//const unsigned short wPropertyNameLength_Label = PROP_NAME_LEN_LABEL;
//const unsigned short bPropertyName_Label[PROP_NAME_LEN_LABEL / 2] = {'L', 'a', 'b', 'e', 'l', 0};
//const unsigned int dwPropertyDataLength_Label = PROP_DATA_LEN_LABEL;
//const unsigned short bPropertyData_Label[PROP_DATA_LEN_LABEL/2] = {'I', 'n', 't', 'e', 'c', 0};


const _USB_GET_STATUS_ANSWER Descr_GetStatus = {2};
const unsigned short * const PID_NUM_COMMON = (const unsigned short * const )0x08002C80;

const _USB_STRING_DESCRIPTOR * const NameDescr_SerialNumber = (const _USB_STRING_DESCRIPTOR * const)0x08002C00;
//{
//    /*	.bLength = */ 40,
//    /*	.bDescriptorType = */ USB_STRING_DESCRIPTOR_TYPE,
//    /*	.wString = */
//    {'M', 'S', 'T', 'N', '_', 'V', '0', '.', '0', '1', '_', 'S', 'N', '0', ('0' + (PID_NUM%100000)/10000), ('0' + (PID_NUM%10000)/1000), ('0' + (PID_NUM%1000)/100), ('0' + (PID_NUM%100)/10), ('0' + PID_NUM%10)}
//};

const _USB_DEVICE_DESCRIPTOR Descr_Device = 
{
    /*	.bLength =*/ 18, // Всегда 18
    /*	.bDescriptorType =*/ USB_DEVICE_DESCRIPTOR_TYPE, // Всегда 1
    /*	.bcdUSB =*/ BCD_VERSION_200, // 0x0100 - USB1.0, 0x0110 - USB1.1, 0x0200 - USB2.0
    /*	.bDeviceClass =*/ 0xEF, // 0xEF - Composite device
    /*	.bDeviceSubClass =*/ 0x02, // 0x02 - Composite device
    /*	.bDeviceProtocol =*/ 0x01, // 0x01 - Composite device
    /*	.bMaxPacketSize0 =*/ 0x40, // Размер буфера конечной точки MDR = 64 байта
    /*	.idVendor =*/ VID_NUM,
    /*	.idProdict =*/ PID_NUM,
    /*	.bcdDevice =*/ DEVICE_VER, // DeviceVersion in BCD format
    /*	.iManufacturer =*/ MANUFACTURER_DESCR_STRING_NUM, // Индекс строки производителя
    /*	.iProduct =*/ PRODUCT_DESCR_STRING_NUM, // Индекс строки названия
    /*	.iSerialNumber =*/ SERIAL_NUMBER_DESCR_STRING_NUM, // Индекс строки серийного номера
    /*	.bNumConfigurations =*/ 0x01 // Одна.
};

const _USB_STRING_DESCRIPTOR NameDescr_ManufacturerEN = {
    /*	.bLength = */ 28, //28,
    /*	.bDescriptorType = */ USB_STRING_DESCRIPTOR_TYPE,
    /*	.wString = */
    {'I', 'N', 'T', 'E', 'C', ' ', 'C', 'o', 'm', 'p', 'a', 'n', 'y'}
};
const _USB_STRING_DESCRIPTOR NameDescr_ManufacturerRU = {
    /*	.bLength = */ 20,
    /*	.bDescriptorType = */ USB_STRING_DESCRIPTOR_TYPE,
    /*	.bString = */
    {0x041D, 0x041F, 0x041A, ' ', 0x0418, 0x041D, 0x0422, 0x0415, 0x041A}, // "НПК ИНТЕК"	
};
const _USB_STRING_DESCRIPTOR Descr_LangID = {
    /*	.bLength = */ 4, // Установить в 6, чтобы включить русский язык
    /*	.bDescriptorType = */ USB_STRING_DESCRIPTOR_TYPE,
    /*	.wString = */
    {LANG_ID_ENGLISH, LANG_ID_RUSSIAN} // 0x0409 = English (United States), 0x0419 = Russian
};
const _USB_STRING_DESCRIPTOR NameDescr_InterfaceData = {
    /*	.bLength = */ 28,
    /*	.bDescriptorType = */ USB_STRING_DESCRIPTOR_TYPE,
    /*	.bString = */
    {'M', 'S', 'T', 'N', '-', 'M', '1', '0', '0', ' ', 'C', 'O', 'M'}
};
const _USB_STRING_DESCRIPTOR NameDescr_InterfaceWinUsb = {
    /*	.bLength = */ 20,
    /*	.bDescriptorType = */ USB_STRING_DESCRIPTOR_TYPE,
    /*	.bString = */
    {'M', 'S', 'T', 'N', '-', 'M', '1', '0', '0'}
};

const _USB_STRING_OS_DESCRIPTOR Descr_MicrosoftOSString = {
    /*	.bLength = */ 0x12,
    /*	.bDescriptorType = */ USB_STRING_DESCRIPTOR_TYPE,
    /*	.qwSignature[7] = */
    {0x4D, 0x00, 0x53, 0x00, 0x46, 0x00, 0x54, 0x00, 0x31, 0x00, 0x30, 0x00, 0x30, 0x00}, //'M', 'S', 'F', 'T', '1', '0', '0',	
    /*	.bMS_VendorCode = */ OS_VENDOR_CODE,
    /*	.bPad = */ 0x01 //  "0x01" = Indicate support for the container ID
};
#define OS_EXT_COMP_ID_HEADER_LENGTH    (0x10)
#define OS_EXT_COMP_ID_FUNC_LENGTH      (0x18)

const _EXTENDED_COMPAT_ID_OS_FEATURE_DESCR_HEADER_SECTION Descr_OSExtCompatID_Header = {
    /* .header.dwLength =*/ OS_EXT_COMP_ID_HEADER_LENGTH + OS_EXT_COMP_ID_FUNC_LENGTH*2,
    /* .header.bcdVersion =*/ BCD_VERSION_100,
    /* .header.wIndex =*/ EXTENDED_COMPAT_ID, // 0x0004 Extended compat ID descriptor
    /* .header.bCount =*/ 0x02, // Number of function sections
    /* .header.bReservedField =*/
    {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}
};

const _EXTENDED_COMPAT_ID_OS_FEATURE_DESCR_FUNCTION_SECTION Descr_OSExtCompatIDFunction_CTRL = {
    /* .bFirstInterfaceNumber =*/ 0x00,
    /* .bReserved =*/ 0x01,
    /* .compatibleID =*/
    {0x57, 0x49, 0x4E, 0x55, 0x53, 0x42, 0x00, 0x00}, // “WINUSB”
    /* .subCompatibleID =*/
    {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},
    /* .bReservedField =*/
    {0x00, 0x00, 0x00, 0x00, 0x00, 0x00}
};

const _EXTENDED_COMPAT_ID_OS_FEATURE_DESCR_FUNCTION_SECTION Descr_OSExtCompatIDFunction_IO = {
    /* .bFirstInterfaceNumber =*/ 0x01,
    /* .bReserved =*/ 0x01,
    /* .compatibleID =*/
    {0x57, 0x49, 0x4E, 0x55, 0x53, 0x42, 0x00, 0x00}, // “WINUSB”
    /* .subCompatibleID =*/
    {0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00},
    /* .bReservedField =*/
    {0x00, 0x00, 0x00, 0x00, 0x00, 0x00}
};

#define OS_EXT_PROP_ID_HEADER_LENGTH    (0x0A)

const _EXTENDED_PROPERTY_OS_FEATURE_DESCR_HEADER Descr_OSFeature_Header = {
    /*	.dwLength =*/ OS_EXT_PROP_ID_HEADER_LENGTH + CUSTOM_PROPERTY_SECTIONS_LENGTH, // The length, in bytes, of the complete extended properties descriptor
    /*	.bcdVersion =*/ BCD_VERSION_100, // Version 1.00 The descriptor’s version number, in binary coded decimal (BCD) format
    /*	.wIndex =*/ EXTENDED_PROPERTIES, // 0x0005 The index for extended properties OS descriptors
    /*	.wCount =*/ 0x01, // The number of custom property sections that follow the header section
};
const _USB_STRING_DESCRIPTOR NameDescr_ConfigurationMSTN = {
    /*	.bLength = */ 34,
    /*	.bDescriptorType = */ USB_STRING_DESCRIPTOR_TYPE,
    /*	.bString = */
    {'C', 'O', 'N', 'F', 'I', 'G', '_', 'M', 'S', 'T', 'N', '_', '0', '.', '0', '3'}
};
const _USB_CONFIGURATION_DESCRIPTOR Descr_Config = {
    /*	.bLength =*/ CONFIGURATION_DESCRIPTOR_LEN, // Длина стандартного дескриптора = 9 байт
    /*	.bDescriptorType =*/ USB_CONFIGURATION_DESCRIPTOR_TYPE,
    /*	.wTotalLength =*/ (CONFIGURATION_DESCRIPTOR_LEN + (INTERFACE_DESCRIPTOR_LEN*3 + ENDPOINT_DESCRIPTOR_LEN * 6)), // ?
    /*	.bNumInterfaces =*/ 3, // Не забудь, если меняешь, соответственно исправить поля bInterfaceNumber и bAlternateSetting в дескрипторах интерфейсов
    /*	.bConfigurationValue =*/ 0x01, // ?
    /*	.iConfiguration =*/ CONFIGURATION_DESCR_STRING_NUM,
    /*	.bmAttributes =*/ (1 << 7 | 0 << 6 | 1 << 5), // 0b11100000 - 1<<7 Зарезервирано, 1<<6 собственное питание, 1<<5 может разбудить хаб
    /*	.MaxPower =*/ (500 / 2), // Максимальное потребление = 500мА
};

const _USB_INTERFACE_DESCRIPTOR Descr_WinUsbInterface_CTRL = {
    /*	.bLengtg =*/ INTERFACE_DESCRIPTOR_LEN,
    /*	.bDescriptorType =*/ USB_INTERFACE_DESCRIPTOR_TYPE,
    /*	.bInterfaceNumber =*/ INTERFACE_WINUSB_CONTROL,
    /*	.bAlternateSetting =*/ 0x00,
    /*	.bNumEndpoints =*/ 2,
    /*	.bInterfaceClass =*/ 0xFF, // Vendor specific
    /*	.bInterfaceSubClass =*/ 0xFF, // Vendor specific
    /*	.bInterfaceProtocol =*/ 0xFF, // Vendor specific
    /*	.iInterface =*/ INTERFACE_WINUSB_DESCR_STRING_NUM
};
const _USB_ENDPOINT_DESCRIPTOR Descr_EP1_WinUsb_IntOut = {
    /*	.bLength =*/ ENDPOINT_DESCRIPTOR_LEN,
    /*	.bDescriptorType =*/ USB_ENDPOINT_DESCRIPTOR_TYPE,
    /*	.bEndpoinAddress =*/ EP_DIRECTION_OUT | EP_ADDRESS_1,
    /*	.bmAttributes =*/ INTERRUPT,
    /*	.wMaxPacketSize =*/ EP_PACKSIZE_64,
    /*	.bInterval =*/ 5 // Поллить каждые 5 фрэймов (1 frame = 1ms)
};
const _USB_ENDPOINT_DESCRIPTOR Descr_EP1_WinUsb_IntIn = {
    /*	.bLength =*/ ENDPOINT_DESCRIPTOR_LEN,
    /*	.bDescriptorType =*/ USB_ENDPOINT_DESCRIPTOR_TYPE,
    /*	.bEndpoinAddress =*/ EP_DIRECTION_IN | EP_ADDRESS_1,
    /*	.bmAttributes =*/ INTERRUPT,
    /*	.wMaxPacketSize =*/ EP_PACKSIZE_64,
    /*	.bInterval =*/ 5 // Поллить каждые 5 фрэймов (1 frame = 1ms)
};
const _USB_INTERFACE_DESCRIPTOR Descr_WinUsbInterface_IO = {
    /*	.bLengtg =*/ INTERFACE_DESCRIPTOR_LEN,
    /*	.bDescriptorType =*/ USB_INTERFACE_DESCRIPTOR_TYPE,
    /*	.bInterfaceNumber =*/ INTERFACE_WINUSB_IO,
    /*	.bAlternateSetting =*/ 0x00,
    /*	.bNumEndpoints =*/ 2,
    /*	.bInterfaceClass =*/ 0xFF, // Vendor specific
    /*	.bInterfaceSubClass =*/ 0xFF, // Vendor specific
    /*	.bInterfaceProtocol =*/ 0xFF, // Vendor specific
    /*	.iInterface =*/ INTERFACE_WINUSB_DESCR_STRING_NUM
};
const _USB_ENDPOINT_DESCRIPTOR Descr_EP2_WinUsb_BulkIn = {
    /*	.bLength =*/ ENDPOINT_DESCRIPTOR_LEN,
    /*	.bDescriptorType =*/ USB_ENDPOINT_DESCRIPTOR_TYPE,
    /*	.bEndpoinAddress =*/ EP_DIRECTION_IN | EP_ADDRESS_2,
    /*	.bmAttributes =*/ BULK,
    /*	.wMaxPacketSize =*/ EP_PACKSIZE_64,
    /*	.bInterval =*/ 0
};
const _USB_ENDPOINT_DESCRIPTOR Descr_EP2_WinUsb_BulkOut = {
    /*	.bLength =*/ ENDPOINT_DESCRIPTOR_LEN,
    /*	.bDescriptorType =*/ USB_ENDPOINT_DESCRIPTOR_TYPE,
    /*	.bEndpoinAddress =*/ EP_DIRECTION_OUT | EP_ADDRESS_2,
    /*	.bmAttributes =*/ BULK,
    /*	.wMaxPacketSize =*/ EP_PACKSIZE_64,
    /*	.bInterval =*/ 0
};


const _USB_INTERFACE_DESCRIPTOR Descr_DataInterface = {
    /*	.bLengtg =*/ INTERFACE_DESCRIPTOR_LEN,
    /*	.bDescriptorType =*/ USB_INTERFACE_DESCRIPTOR_TYPE,
    /*	.bInterfaceNumber =*/ INTERFACE_DATA,
    /*	.bAlternateSetting =*/ 0x00,
    /*	.bNumEndpoints =*/ 0x02,
    /*	.bInterfaceClass =*/ 0x02, // Communications and CDC Control
    /*	.bInterfaceSubClass =*/ 0x02,   //Abstract Control Model
    /*	.bInterfaceProtocol =*/ 0x00, // Protocol: none
    /*	.iInterface =*/ INTERFACE_DATA_DESCR_STRING_NUM
};
const _USB_ENDPOINT_DESCRIPTOR Descr_EP3_DataInterface_BulkOut = {
    /*	.bLength =*/ ENDPOINT_DESCRIPTOR_LEN,
    /*	.bDescriptorType =*/ USB_ENDPOINT_DESCRIPTOR_TYPE,
    /*	.bEndpoinAddress =*/ EP_DIRECTION_OUT | EP_ADDRESS_3,
    /*	.bmAttributes =*/ BULK,
    /*	.wMaxPacketSize =*/ EP_PACKSIZE_64,
    /*	.bInterval =*/ 0
};
const _USB_ENDPOINT_DESCRIPTOR Descr_EP3_DataInterface_BulkIn = {
    /*	.bLength =*/ ENDPOINT_DESCRIPTOR_LEN,
    /*	.bDescriptorType =*/ USB_ENDPOINT_DESCRIPTOR_TYPE,
    /*	.bEndpoinAddress =*/ EP_DIRECTION_IN | EP_ADDRESS_3,
    /*	.bmAttributes =*/ BULK,
    /*	.wMaxPacketSize =*/ EP_PACKSIZE_64,
    /*	.bInterval =*/ 0 
};

#endif /* __mstn_usb_descriptors_composite_h */