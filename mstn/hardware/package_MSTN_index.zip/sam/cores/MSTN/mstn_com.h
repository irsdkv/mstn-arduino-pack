/*!
  * \file    mstn_com.h
  * \author  Intec Group
  * \version V2.0.0
  * \date    14/02/2017
  * \brief   This file contains all the required functions prototypes for the MSTN COM firmware library.
  *
  * \warning THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, INTEC SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * \copyright COPYRIGHT 2017 Intec Group
*/

#ifndef __mstn_com_h
#define __mstn_com_h

#include "mstn_types.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct
{
  uint32_t dwDTERate;       // Data terminal rate, in bits per second.
  uint8_t  bCharFormat;     // 0: 1 Stop bit
                            // 1: 1.5 Stop bits
                            // 2: 2 Stop bits
  uint8_t  bParityType;     // Parity:
                            // 0: None
                            // 1: Odd
                            // 2: Even
                            // 3: Mark
                            // 4: Space
  uint8_t  bDataBits;       // Data bits (5, 6, 7, 8 or 16).
}_COM_LineCodingStruct;

typedef enum{
    COM_TRANSFER_DONE,
    USB_NOT_CONNECTED,
    DTE_NOT_PRESENT
}_COM_Result;

/*!
 * \brief   Printf() для потока COM порта. 
 * \details Размер буфера 128 байт.
 *          Размер кругового буфера - 128 байт. Если произойдет переполнение
 *          буффера - будут отправлены 128 байт, добавленные последними.
 *          Останавливает выполнение программы в текущем контексте до 
 *          выполнения отправки или разрыва соединения.
 * \warning Внимание! Если передача по COM соединению ведется более чем
 *          в одном контексте выполнения программы, вызов данной функции 
 *          может привести к некорректному поведению программы.
 * \param   См. printf().
 * \retval  _ErrorStatus:
 *              \arg COM_TRANSFER_DONE - передача выполнена успешно.
 *              \arg USB_NOT_CONNECTED - USB соединение не установлено.
 *              \arg DTE_NOT_PRESENT - оконечное оборудование отсутствует.
 */
_COM_Result COM_Printf(const char *arg, ...);

/*!
 * \brief   Передает массив байт как бинарный код через последовательное соединение.
 * \details Размер кругового буфера - 128 байт. Если произойдет переполнение
 *          буффера - будут отправлены 128 байт, добавленные последними.
 *          Останавливает выполнение программы в текущем контексте до 
 *          выполнения отправки или разрыва соединения.
 * \warning Внимание! Если передача по COM соединению ведется более чем
 *          в одном контексте выполнения программы, вызов данной функции 
 *          может привести к некорректному поведению программы.
 * \param   buff - массив для передачи
 * \param   length - количество байт для передачи
 * \retval  _ErrorStatus:
 *              \arg COM_TRANSFER_DONE - передача выполнена успешно.
 *              \arg USB_NOT_CONNECTED - USB соединение не установлено.
 *              \arg DTE_NOT_PRESENT - оконечное оборудование отсутствует.
 */
_COM_Result COM_Print(const char *buff, uint16_t length);

/*!
 * \brief   Передает массив байт как бинарный код через последовательное соединение.
 * \details Размер кругового буфера - 128 байт. Если произойдет переполнение
 *          буффера - будут отправлены 128 байт, добавленные последними.
 *          НЕ останавливает выполнение программы до выполнения отправки.
 *          Вы можете проконтролировать отправку сообщения по значению
 *          переменной, адрес которой передан как третий аргумент.
 * \param   buff - массив для передачи
 * \param   length - количество байт для передачи. Максимальное число байт 128.
 * \retval  Нет
 */
void COM_Send(const char *buff, uint16_t length);

/*!
 * \brief   COM_SendCopy() с форматированием.
 * \param   buff - массив для передачи
 * \param   length - количество байт для передачи. Максимальное число байт 128.
 * \retval  Нет
 */
void COM_Sendf(const char *arg, ...);

/*!
 * \brief   Возвращает состояние передачи.
 * \param   Нет
 * \retval  bool:
 *          \arg TRUE - все данные переданы.
 *          \arg FALSE - отправка данных не завершена.
. */
bool COM_IsDataTransferred( void );

/*!
 * \brief   Активирует канал приема COM порта и ожидает принятия 
 *          данных через COM интерфейс в течение maxWaitTime миллисекунд.
 * \details Данные по виртуальному COM интерфейсу могут приняты ТОЛЬКО
 *          во время выполнения данной функции или во время передачи
 *          данных. Буфер может хранить до 128 байт, однако функция вернет
 *          общее количество байт, принятых после последнего обращения к функциям COM_Read() или
 *          COM_Peek(), даже если количество принятых байт превышает длину буфера (при этом доступными 
 *          будут только последние 128 принятых байт). Таким образом можно отследить событие 
 *          переполнения буфера.
 *          Максимальное количество байт для приема за одну транзакцию - 64 байта. Таким образом,
 *          если с ПК будет выслана посылка длиной более 64 байтов - функция всё равно вернет
 *          значение 64, остальные байты посылки будут приняты в следующей транзакции (которая 
 *          произойдет примерно через 1мс).
 *          Для ОС Windows 7/8.1, при использовании "MSTN_COM_Terminal_Simulator.exe", минимальное 
 *          рекомендуемое время ожидания - 25мс.
 *                     
 * \param   maxWaitTime - время ожидания в милисекундах.
 * \retval  int - Количество принятых байт.
 */
int COM_Wait(uint32_t maxWaitTime);

/*!
 * \brief   Функция получает количество байт(символов) доступных для чтения из 
 *          COM интерфейса. 
 * \details Это те байты которые уже поступили и записаны 
 *          в буфер COM соединения. Буфер может хранить до 128 байт, однако функция вернет
 *          общее количество байт, принятых после последнего обращения к функциям COM_Read() или
 *          COM_Peek(), даже если количество принятых байт превышает длину буфера (при этом доступными 
 *          будут только последние 128 принятых байт). Таким образом можно отследить событие 
 *          переполнения буфера.
 * \warning Данные по виртуальному COM интерфейсу могут приняты ТОЛЬКО
 *          во время выполнения функции COM_Wait или во время передачи данных.
 * \retval  Количество байт доступных для чтения.
 */
int COM_Available( void );

/*!
 * \brief   Функция считывает очередной доступный байт из буфера COM соединения.
 * \details Если при обращении к функции буфер приема переполнен, значение "количество доступных байт" сбрасывается к длине 
 *          буфера (т.е. следующее за этим обращение к функции COM_Available() вернет значение (128 - 1)).
 *          Длина буфера составляет 128 байтов, однако рекомендуется посылать на плату не 
 *          более 64-х байт за одну посылку, во избежание нарушения порядка байтов.
 * \param   Нет
 * \retval  Следующий доступный байт или -1 если его нет.
 */
int COM_Read( void );

/*!
 * \brief   Возвращает следующий доступный байт (символ) из буфера входящего COM 
 *          соединения, не удаляя его из этого буфера. 
 * \details То есть успешный вызов этой функции 
 *          вернет тоже значение, что и следующий за ним вызов функции COM_Read().
 * \param   Нет
 * \retval  Следующий доступный байт или -1 если его нет.
 */
int COM_Peek( void );

/*!
 * \brief   Помещает в переменную, указатель которой 
 *          передан в аргументе, текущее значение
 *          параметров линии.
 * \param   lineCodingState - указатель на структуру параметров линии.
 * \retval  Нет
 */
void COM_GetCurrentLineCodingState(_COM_LineCodingStruct * lineCodingState);

/*!
 * \brief   Возвращает текущее значение CONTROL LINE STATE.
 * \param   Нет
 * \retval  uint16_t: битовое поле:
 *          - Биты 15:2 -  Reserved (Reset to zero).
 *          - Бит 1 - Carrier control for half duplex modems. This signal corresponds to V.24 signal 105 and RS232 signal RTS.
 *                  -# 0: Deactivate carrier.
 *                  -# 1: Activate carrier.
 *          (The device ignores the value of this bit when operating in full duplex mode)
 *          - Бит 0 - Indicates to DCE if DTE is present or not.This signal corresponds to V.24 signal 108/2 and RS232 signal DTR.
 *                  -# 0: DTE is not present.
 *                  -# 1: DTE is present.
 */
uint16_t COM_GetCurrentControlLineState( void );

/*!
 * \brief   Возвращает присутствие или отсутствие DTE (оконечное 
 *          оборудование данных) на линии.
 * \param   Нет
 * \retval  bool: 
 *          \arg FALSE - DTE не присутствует.
 *          \arg TRUE - DTE присутствует.
 */
bool COM_IsDtePresent( void );

#ifdef __cplusplus
}
#endif

#endif /* __mstn_com_h */

