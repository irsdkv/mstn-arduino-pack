/*!
  * \file    mstn_control.h
  * \author  Intec Group
  * \version V2.0.0
  * \date    03/02/2017
  * \brief   This file contains all the required functions prototypes for the MSTN USB control firmware library.
  *
  * \warning THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, INTEC SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * \copyright COPYRIGHT 2017 Intec Group
*/

#ifndef __mstn_control_h
#define __mstn_control_h

#include "mstn_types.h"

#ifdef __cplusplus
extern "C" {
#endif
    
typedef struct {
	uint8_t bMstnRequestType;
	uint8_t bMstnRequestSubType;
	uint8_t bValue;
	uint8_t bDataLength;
	uint8_t data[60];
}_CONTROL_TRANSFER_REQUEST, *_PCONTROL_TRANSFER_REQUEST;

void ControlCommandsHandler(void);
void ControlCommandsHandler_Boot(_PCONTROL_TRANSFER_REQUEST mstnRequestData);

#ifdef __cplusplus
}
#endif

#endif /* __mstn_control_h */
