/*!
  * \file    mstn_eeprom_external.h
  * \author  Intec Group
  * \version V2.0.0
  * \date    20/08/2016
  * \brief   This file contains all the required functions prototypes for the MSTN EEPROM EXT firmware library.
  *
  * \warning THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, INTEC SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * \copyright COPYRIGHT 2017 Intec Group
*/

#ifndef __mstn_eeprom_external_h
#define __mstn_eeprom_external_h

#include "mstn_types.h"
#include "mstn_spi.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SCHEMATIC_V02
#define EEPROM_EXT_SELECT_PIN_NUM   (E20)
#define EEPROM_EXT_HOLD_PIN_NUM     (E24)
#else
#define EEPROM_EXT_SELECT_PIN_NUM   (E17)   // Connected in Schematic Ver>=0.4
#define EEPROM_EXT_HOLD_PIN_NUM     (E16)   // Connected in Schematic Ver>=0.4
#endif

#define EEPROM_EXT_SIZE_BYTES       (0x20000)
#define EEPROM_EXT_ADDRESS_START    (0x0)
#define EEPROM_EXT_ADDRESS_END      (0x1FFFF)

/*!
 * \brief   Инициирует шину SPI1 со скоростью, равной 16/divider [МГц] и в режиме mode.
 * \details Длина кадров интерфейса задается автоматически:
 *          WordLen = SPI_WL8.
 *          Для работы с микросхемой EEPROM памяти, размещенной на плате,
 *          используется интерфейс SPI1 и дополнительно выводы E16 и E17.
 *          Эти выводы настраиваются как выходы и служат для управления микросхемой памяти
 *          в процессе работы с ней. Вывод E20 используется как линия 
 *          выбора микросхемы EEPROM памяти как ведомого устройства SPI.
 *          Выбор режима и скорости не влияет на работу с микросхемой памяти, 
 *          и предоставлен для упрощения возможности управления несколькими устройствами на шине SPI1.
 * \param   mode - режим работы интерфейса SPI.
 *          Этот параметр может принимать следующие значения:
 *              \arg SPI_MODE0
 *              \arg SPI_MODE3
 * \param   divider - Делитель частоты. Этот параметр не может быть менее 2-х и более 256-и.
 * \retval  Нет
 */
void EEPROM_EXT_Begin(_SPI_Mode mode, int divider);

/*!
 * \brief   Считывает из микросхемы EEPROM памяти массив байтов длиной len,
 *          начиная с адреса address и помещает их в буфер buff.
 * \details Если сумма начального адреса считывания и запрошенного количества байт
 *          больше чем EEPROM_EXT_ADDRESS_END - будет считано 
 *          (EEPROM_EXT_ADDRESS_END - address + 1) байтов.
 * \param   address - Адрес первого байта для считывания. Этот параметр не может быть меньше ноля 
 *          и больше EEPROM_EXT_ADDRESS_END.
 * \param   buff - Массив для сохранения считанных данных.
 * \param   len - Количество считываемых байтов. Этот параметр не может быть меньше ноля.
 * \retval  Количество фактически считанных байтов. -1 если входные данные некорректны
 *          или интерфейс связи с микросхемой памяти не инициализирован.
 */
int EEPROM_EXT_Read(int address, char *buff, int len);

/*!
 * \brief   Считывает из микросхемы EEPROM памяти байт по адресу address.
 * \param   address - Адрес байта для считывания.
 * \retval  Считанный байт. -1 если адрес некорректен или интерфейс связи с микросхемой памяти не инициализирован.
 */
int EEPROM_EXT_ReadByte(int address);

/*!
 * \brief   Записывает в микросхему EEPROM памяти массив байтов buff длиной len,
 *          начиная с адреса address и помещает их в буфер buff.
 * \details Если сумма начального адреса записи и запрошенного количества байт на запись
 *          больше чем EEPROM_EXT_ADDRESS_END - будет записано 
 *          (EEPROM_EXT_ADDRESS_END - address + 1) байтов.
 * \param   address - Адрес байта для считывания.
 * \retval  Количество фактически записанных байтов. -1 если входные данные некорректны или 
 *          интерфейс связи с микросхемой памяти не инициализирован.
 */
int EEPROM_EXT_Write(int address, char *buff, int len);

/*!
 * \brief   Записывает в микросхему EEPROM памяти байт по адресу address.
 * \param   address - Адрес байта для записи.
 * \retval  Количество фактически записанных байтов. -1 если входные данные некорректны или 
 *          интерфейс связи с микросхемой памяти не инициализирован.
 */
int EEPROM_EXT_WriteByte(int address, char byte);

/*!
 * \brief   Деинициализирует интерфейс SPI1, не изменяя режим работы выводов, принимавших участие в обмене.
 * \param   Нет
 * \retval  Нет
 */
void EEPROM_EXT_End( void );

#ifdef __cplusplus
}
#endif

#endif /* __mstn_eeprom_external_h */

