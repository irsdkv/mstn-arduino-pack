/*!
  * \file    mstn_types.h
  * \author  Intec Group
  * \version V2.0.0
  * \date    17/02/2017
  * \brief   This file contains some of the data types for MSTN firmware library.
  *
  * \warning THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, INTEC SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * \copyright COPYRIGHT 2017 Intec Group
  */

#ifndef __mstn_types_h
#define __mstn_types_h

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#ifndef NULL
#   ifndef __cplusplus
#       define NULL ((void *)0)
#   else   /* C++ */
#       define NULL 0
#   endif  /* C++ */
#endif  /* NULL */

#ifndef __cplusplus

typedef enum {
    e_FALSE = 0, e_TRUE = 1
}bool;

#define FALSE   (e_FALSE)
#define TRUE    (e_TRUE)

#endif  // __cplusplus

enum{
    PORTA = 0,
    PORTB = 1,
    PORTC = 2,
    PORTD = 3,
    PORTE = 4,
    PORTF = 5
};

enum{
    D0 = 0,
    D1 = 1,
    D2 = 2,
    D3 = 3,
    D4 = 4,
    D5 = 5,
    D6 = 6,
    D7 = 7,
    D8 = 8,
    D9 = 9,
    D10 = 10,
    D11 = 11,
    D12 = 12,
    D13 = 13,

    A0 = 14,
    A1 = 15,
    A2 = 16,
    A3 = 17,
    A4 = 18,
    A5 = 19,

    E0 = 20,
    E1 = 21,
    E2 = 22,
    E3 = 23,
    E4 = 24,
    E5 = 25,
    E6 = 26,
    E7 = 27,
    E8 = 28,
    E9 = 29,
    E10 = 30,
    E11 = 31,
    E12 = 32,
    E13 = 33,
    E14 = 34,
    E15 = 35,
    E16 = 36,
    E17 = 37,

#ifdef SCHEMATIC_V02
    E18 = 38,
    E19 = 39,
    E20 = 40,
    E21 = 41,
    E22 = 42,
    E23 = 43,
    E24 = 44
#endif
};

#ifdef SCHEMATIC_V02
#define MAX_PIN_NUM                     (E24)
#else
#define MAX_PIN_NUM                     (E17)
#endif

#define IS_PINNUM_INCORRECT(pinnum)        ((pinnum) > MAX_PIN_NUM)

typedef enum {
    R_SUCCESS = 0, R_ERROR =! R_SUCCESS
} _ErrorStatus;

typedef enum{
    INPUT = 0,
    OUTPUT = 1,
    INPUT_PULLUP = 2,
    DIGITAL_INPUT = 0,
    DIGITAL_OUTPUT = 1,
    DIGITAL_INPUT_PULLUP = 2,
    DIGITAL_INPUT_PULLDOWN = 3,
    ANALOG_INPUT = 4,
    ANALOG_REF = 5,
    PM_UART = 6,
    PM_SPI = 7,
    PM_I2C = 8,
    PM_PWM = 9,
    EXT_INT_FALLING_EDGE = 10,
    EXT_INT_RISING_EDGE = 11,
    EXT_INT_CHANGE = 12,
    PM_DAC = 13,
    COMP_IN = 14,
    COMP_OUT = 15,
    NOT_AVAILABLE = 16,
    OTHER = 17
} _PinMode;

typedef enum {
    JP1_ADC = 0,
    JP1_I2C = 1
}_StatesJp1;

typedef enum {
    MAIN_ARGS_DISABLE = 0,
    MAIN_ARGS_WAIT_5_SEC = 1,
    MAIN_ARGS_WAIT_INDEFINITELY = 2
}_MainArgs;

typedef enum{
    BIN = 2,
    OCT = 8,
    DEC = 10,
    HEX = 16,
}_Notation;

#ifdef __cplusplus
}
#endif

#endif /* __mstn_types_h */
