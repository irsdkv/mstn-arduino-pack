/*!
  * \file    pins_mstn.h
  * \author  Intec Group
  * \version V2.0.0
  * \date    17/02/2017
  * \brief   ---
  *
  * \warning THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, INTEC SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * \copyright COPYRIGHT 2017 Intec Group
  */

#ifndef PINS_MSTN_H
#define PINS_MSTN_H

#include "MDR32Fx.h"
#include "mstn_types.h"
#include "mstn.h"

#ifdef __cplusplus
extern "C" {
#endif
    
static MDR_PORT_TypeDef falseReg __attribute__((unused));

#define D0_PORT         MDR_PORTB
#define D0_BITNUM       (6)
#define D1_PORT         MDR_PORTB
#define D1_BITNUM       (5)
#define D2_PORT         MDR_PORTA
#define D2_BITNUM       (0)
#define D3_PORT         MDR_PORTA
#define D3_BITNUM       (4)
#define D4_PORT         MDR_PORTA
#define D4_BITNUM       (3)
#define D5_PORT         MDR_PORTA
#define D5_BITNUM       (2)
#define D6_PORT         MDR_PORTA
#define D6_BITNUM       (1)
#define D7_PORT         MDR_PORTA
#define D7_BITNUM       (5)
#define D8_PORT         MDR_PORTC
#define D8_BITNUM       (2)
#define D9_PORT         MDR_PORTB
#define D9_BITNUM       (7)
#define D10_PORT        MDR_PORTF
#define D10_BITNUM      (2)
#define D11_PORT        MDR_PORTF
#define D11_BITNUM      (0)
#define D12_PORT        MDR_PORTF
#define D12_BITNUM      (3)
#define D13_PORT        MDR_PORTF
#define D13_BITNUM      (1)

#define A0_PORT         MDR_PORTD
#define A0_BITNUM       (2)
#define A1_PORT         MDR_PORTD
#define A1_BITNUM       (3)
#define A2_PORT         MDR_PORTD
#define A2_BITNUM       (6)
#define A3_PORT         MDR_PORTD
#define A3_BITNUM       (5)
#define A4_PORT         MDR_PORTD
#define A4_BITNUM       (4)
#define A5_PORT         MDR_PORTD
#define A5_BITNUM       (7)

#ifdef SCHEMATIC_V02
#define E0_PORT         ((MDR_PORT_TypeDef *)(NULL))
#define E0_BITNUM       (0)
#define E1_PORT         A4_PORT
#define E1_BITNUM       A4_BITNUM
#define E2_PORT         A5_PORT
#define E2_BITNUM       A5_BITNUM
#define E3_PORT         MDR_PORTE
#define E3_BITNUM       (0)
#define E4_PORT         MDR_PORTE
#define E4_BITNUM       (1)
#define E5_PORT         MDR_PORTB
#define E5_BITNUM       (8)
#define E6_PORT         MDR_PORTE
#define E6_BITNUM       (2)
#define E7_PORT         MDR_PORTB
#define E7_BITNUM       (9)
#define E8_PORT         MDR_PORTE
#define E8_BITNUM       (3)
#define E9_PORT         MDR_PORTA
#define E9_BITNUM       (7)
#define E10_PORT        MDR_PORTA
#define E10_BITNUM      (6)
#define E11_PORT        MDR_PORTC
#define E11_BITNUM      (1)
#define E12_PORT        MDR_PORTC
#define E12_BITNUM      (0)
#define E13_PORT        ((MDR_PORT_TypeDef *)(NULL))
#define E13_BITNUM      (0)
#define E14_PORT        ((MDR_PORT_TypeDef *)(NULL))
#define E14_BITNUM      (0)
#define E15_PORT        ((MDR_PORT_TypeDef *)(NULL))
#define E15_BITNUM      (0)
#define E16_PORT        ((MDR_PORT_TypeDef *)(NULL))
#define E16_BITNUM      (0)
#define E17_PORT        ((MDR_PORT_TypeDef *)(NULL))
#define E17_BITNUM      (0)
#define E18_PORT        MDR_PORTB
#define E18_BITNUM      (10)
#define E19_PORT        MDR_PORTD
#define E19_BITNUM      (1)
#define E20_PORT        MDR_PORTF
#define E20_BITNUM      (4)
#define E21_PORT        MDR_PORTD
#define E21_BITNUM      (0)
#define E22_PORT        MDR_PORTF
#define E22_BITNUM      (5)
#define E23_PORT        ((MDR_PORT_TypeDef *)(NULL))
#define E23_BITNUM      (0)
#define E24_PORT        MDR_PORTF
#define E24_BITNUM      (6)
#else
#define E0_PORT         A4_PORT
#define E0_BITNUM       A4_BITNUM
#define E1_PORT         A5_PORT
#define E1_BITNUM       A5_BITNUM
#define E2_PORT         MDR_PORTE
#define E2_BITNUM       (0)
#define E3_PORT         MDR_PORTE
#define E3_BITNUM       (1)
#define E4_PORT         MDR_PORTB
#define E4_BITNUM       (8)
#define E5_PORT         MDR_PORTE
#define E5_BITNUM       (2)
#define E6_PORT         MDR_PORTB
#define E6_BITNUM       (9)
#define E7_PORT         MDR_PORTE
#define E7_BITNUM       (3)
#define E8_PORT         MDR_PORTA
#define E8_BITNUM       (7)
#define E9_PORT         MDR_PORTA
#define E9_BITNUM       (6)
#define E10_PORT        MDR_PORTC
#define E10_BITNUM      (1)
#define E11_PORT        MDR_PORTC
#define E11_BITNUM      (0)
#define E12_PORT        MDR_PORTD
#define E12_BITNUM      (0)
#define E13_PORT        MDR_PORTB
#define E13_BITNUM      (10)
#define E14_PORT        MDR_PORTD
#define E14_BITNUM      (1)
#define E15_PORT        MDR_PORTF
#define E15_BITNUM      (5)
#define E16_PORT        MDR_PORTF
#define E16_BITNUM      (6)
#define E17_PORT        MDR_PORTF
#define E17_BITNUM      (4)
#endif
static volatile uint32_t * const pins_rxtx_bitband_addr[] = {
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&D0_PORT->RXTX,D0_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&D1_PORT->RXTX,D1_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&D2_PORT->RXTX,D2_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&D3_PORT->RXTX,D3_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&D4_PORT->RXTX,D4_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&D5_PORT->RXTX,D5_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&D6_PORT->RXTX,D6_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&D7_PORT->RXTX,D7_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&D8_PORT->RXTX,D8_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&D9_PORT->RXTX,D9_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&D10_PORT->RXTX,D10_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&D11_PORT->RXTX,D11_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&D12_PORT->RXTX,D12_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&D13_PORT->RXTX,D13_BITNUM),
    
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&A0_PORT->RXTX,A0_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&A1_PORT->RXTX,A1_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&A2_PORT->RXTX,A2_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&A3_PORT->RXTX,A3_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&A4_PORT->RXTX,A4_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&A5_PORT->RXTX,A5_BITNUM),
    
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&E0_PORT->RXTX,E0_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&E1_PORT->RXTX,E1_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&E2_PORT->RXTX,E2_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&E3_PORT->RXTX,E3_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&E4_PORT->RXTX,E4_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&E5_PORT->RXTX,E5_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&E6_PORT->RXTX,E6_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&E7_PORT->RXTX,E7_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&E8_PORT->RXTX,E8_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&E9_PORT->RXTX,E9_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&E10_PORT->RXTX,E10_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&E11_PORT->RXTX,E11_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&E12_PORT->RXTX,E12_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&E13_PORT->RXTX,E13_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&E14_PORT->RXTX,E14_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&E15_PORT->RXTX,E15_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&E16_PORT->RXTX,E16_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&E17_PORT->RXTX,E17_BITNUM),
#ifdef SCHEMATIC_V02
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&E18_PORT->RXTX,E18_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&E19_PORT->RXTX,E19_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&E20_PORT->RXTX,E20_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&E21_PORT->RXTX,E21_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&E22_PORT->RXTX,E22_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&E23_PORT->RXTX,E23_BITNUM),
    (volatile uint32_t*)BITBAND_BIT_ADDR((uint32_t)&E24_PORT->RXTX,E24_BITNUM)
#endif
};

#ifdef __cplusplus
}
#endif

#endif /* PINS_MSTN_H */

