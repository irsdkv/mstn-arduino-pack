/*!
  * \file    mstn_dac.h
  * \author  Intec Group
  * \version V2.0.0
  * \date    03/10/2016
  * \brief   This file contains all the required functions prototypes for the MSTN DAC firmware library.
  *
  * \warning THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, INTEC SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * \copyright COPYRIGHT 2017 Intec Group
*/

#ifndef __mstn_dac_h
#define __mstn_dac_h

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SCHEMATIC_V02
#define DAC_OUT_PIN         (E3)
#define DAC_REF_HIGH_PIN    (E4)
#else
#define DAC_OUT_PIN         (E2)
#define DAC_REF_HIGH_PIN    (E3)
#endif

typedef enum{
    SOURCE_INTERNAL,    // 3V3
    SOURCE_EXTERNAL     // DAC Ref
}_DAC_RefSource;


/*!
 * \brief   DAC_Begin - Инициализирует модуль ЦАП.
 * \param   source: Источник опорного уровня.
 * \retval  Нет
 */
void DAC_Begin(_DAC_RefSource source);

/*!
 * \brief   DAC_DacWrite - Устанавливает выходной уровень на выводе DAC_OUT.
 * \param   value: Значение для установки. 
 *                 Должно находиться в диапазоне от 0 (0В) до 0xFFF (3.3V или 1*DAC_REF)
 * \retval  Нет
 */
void DAC_DacWrite(int value);

/*!
 * \brief   DAC_End - Деинициализация модуля DAC и установка используемых выводов в режим DIGITAL_OUT.
 * \retval  Нет
 */
void DAC_End( void );


#ifdef __cplusplus
}
#endif

#endif /* __mstn_dac_h */

