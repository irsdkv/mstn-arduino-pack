/*!
  * \file    mstn_i2c.h
  * \author  Intec Group
  * \version V1.0.0
  * \date    03/10/2016
  * \brief   This file contains all the required functions prototypes for the MSTN I2C firmware library.
  *
  * \warning THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, INTEC SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * \copyright COPYRIGHT 2017 Intec Group
  */

/* 03.10.2016 ВНИМАНИЕ! Модуль не отлажен! Возможна его некорректная работа. */

#ifndef __mstn_i2c_h
#define __mstn_i2c_h

#include "mstn_types.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SCHEMATIC_V02
#define I2C_SCL_PIN     (E12)
#define I2C_SDA_PIN     (E11)
#else
#define I2C_SCL_PIN     (E11)
#define I2C_SDA_PIN     (E10)
#endif

#define I2CBUFFLEN      (1024)

/*!
 * \brief   Инициализация к шины I2C в качестве мастера (400kHz).
 * \param   Нет
 * \retval  Нет
 */
void I2C_BeginAsMaster( void );

/*!
 * \brief   Используется мастером для запроса байта от ведомого устройства (слейва). 
 * \details Байты могут быть получены с помощью методов available() и read().
 * \param   address: 7-битный адрес устройства для запроса байтов данных
 * \param   quantity: количество запрошенных байт.
 * \retval  int: число считанных байт.
 */
int I2C_RequestFrom(unsigned char address, int quantity);

/*!
 * \brief   Начало передачи I2C для ведомого устройства (слейва) с 
 *          заданным адресом. Затем, нужно вызвать метод I2C_Write() 
 *          или I2C_WriteBuff() для добавления последовательности 
 *          байт в очередь предназначенных для передачи, и выполнить 
 *          саму передачу данных методом I2C_EndTransmission().
 * \param   address: 7-битный адрес устройства для передачи.
 * \retval  Нет
 */
void I2C_BeginTransmission(unsigned char address);

/*!
 * \brief   Завершает передачу данных для ведомого устройства, 
 *          которое было начато beginTransmission() и, фактически, 
 *          осуществляет перечу байт, которые были поставлены в очередь 
 *          методами I2C_Write() и I2C_WriteBuff().
 * \param   Не.
 * \retval  int - Статус передачи:
 *			     \arg 0: успех
 *               \arg 1: данных слишком много и они не помещается в буфер передачи (фактически не используется,
 *                       т.к. ф-ии I2C_Write() и I2C_WriteBuff() не добавят в очередь лишние данные).
 *                       Оставлено для совместимости с библиотекой Arduino Wire.
 *               \arg 2: получили NACK на передачу адреса
 *               \arg 3: получили NACK на передачу данных
 *               \arg 4: другая ошибка
 */
int I2C_EndTransmission( void );

/*!
 * \brief   Записывает данные от ведомого устройства (slave) в ответ на запрос 
 *          мастера (в промежутках между вызовами I2C_BeginTransmission() и I2C_EndTransmission()).
 * \param   data: байт для отправки.
 * \retval  int - возвращает число записанных байт.
 */
int I2C_Write(unsigned char data);

/*!
 * \brief   Записывает очередь байт для передачи от мастера к ведомому 
 *          устройству (в промежутках между вызовами I2C_BeginTransmission() и I2C_EndTransmission()).
 * \param   data: адрес начала массива.
 * \param   quantity: число байт для передачи.
 * \retval  int - возвращает число записанных байт.
 */
int I2C_WriteBuff(const unsigned char *data, int quantity);

/*!
 * \brief   Возвращает количество байт, доступных для получения.  
 * \details Этот метод должно быть вызван после вызова I2C_RequestFrom().
 * \param   Нет
 * \retval  int - Число байт, доступных для чтения.
 */
int I2C_Available( void );

/*!
 * \brief   Считывает байт, который был передан от ведомого устройства(слейва) к 
 *          мастеру, после вызова I2C_RequestFrom() или был передан от мастера к слейву. 
 * \param   Нет
 * \retval  int - Следующий полученный байт.
 */
int I2C_Read( void );

#ifdef __cplusplus
}
#endif

#endif /* __mstn_i2c_h */

