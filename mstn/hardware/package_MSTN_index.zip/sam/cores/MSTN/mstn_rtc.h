/*!
  * \file    mstn_rtc.h
  * \author  Intec Group
  * \version V2.0.0
  * \date    16/10/2016
  * \brief   This file contains all the required functions prototypes for the MSTN RTC firmware library.
  *
  * \warning THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, INTEC SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * \copyright COPYRIGHT 2017 Intec Group
  */

#ifndef __mstn_rtc_h
#define __mstn_rtc_h

#include "time.h"
#include "sys/time.h"

#ifdef __cplusplus
extern "C" {
#endif

/*!
 *          На плате MSTN установлен кварцевый генератор с номинальной частотой  32768Гц.
 *          Если Вы хотите точно настроить скорость хода часов 
 *          реального времени, Вы можете использовать функцию RTC_SetCalibration и функцию
 *          RTC_SetPrescaler для того, чтобы сделать это.
 *          Например:
 *          Чтобы несколько ускорить ход часов - установите основание счетчика
 *          меньше 32768 и установите коэффициент подстройки с помощью 
 *          функции RTC_SetCalibration.
 *          Чтобы несколько замедлить ход часов - установите коэффициент подстройки с помощью 
 *          функции RTC_SetCalibration.
*/

/*!
 * \brief  Устанавливает коэффициент подстройки тактовой частоты часов реального времени.
 * \details Из каждых 2^20 тактов будет замаскировано calibration тактов:
 *             \arg 00000000 – 0 тактов
 *             \arg 00000001 – 1 такт
 *             \arg ...
 *             \arg 11111111 – 256 тактов
 *             
 *             Таким образом, при частоте 32768.00000 Гц:
 *             \arg при calibration = 0 тактов частота = 32768.00000 Гц
 *             \arg при calibration = 1 такт частота = 32767,96875 Гц;
 *             \arg ...
 *             \arg при calibration = 256 тактов частота = 32760.00000 Гц
 * \param  calibration: Коэффициент подстройки.
 *         \arg 0 <= calibration <= 255.
 * \retval Нет
 */
void RTC_SetCalibration(uint32_t calibration);

/*!
 * \brief  Устанавливает значение основания для счета счетчика 
 *         предварительного делителя часов реального времени.
 * \param  prescalerValue: Значение основания. Должно быть меньше 0x000FFFFF.
 * \retval Нет
*/
void RTC_SetPrescaler(uint32_t prescalerValue);

/*!
 * \brief   Устанавливает функцию (обработчик прерывания), которая вызовется 
 *          в момент наступления (в блоке часов реального времени) секунды, 
 *          переданной во втором аргументе.
 * \details Данное прерывание разбудит процессор, если он находится в режиме STANDBY.
 * \param   isr: функция для вызова в прерывании.
 * \param   sec: секунда вызова прерывания.
 * \retval  Нет
 */
void RTC_AttachInterrupt(void (*isr)(), uint32_t sec);

/*!
 * \brief   Отключает обработчик прерывания.
 * \param   Нет
 * \retval  Нет
 */
void RTC_DetachInterrupt( void );

/*!
 * \brief   Возвращает количество миллисекунд, прошедшее с момента старта пользовательской программы (момент входа в main()).
 * \param   Нет
 * \retval  uint32_t - кол-во миллисекунд.
 */
uint32_t RTC_millis( void );

/*!
 * \brief   Возвращает количество микросекунд, прошедшее с момента старта пользовательской программы (момент входа в main()).
 * \param   Нет
 * \retval  unsigned_long - кол-во микросекунд (точность составляет 30.52мкс).
 */
uint32_t RTC_micros( void );

#ifdef __cplusplus
}
#endif

#endif /* __mstn_rtc_h */

