/*!
  * \file    mstn_port.h
  * \author  Intec Group
  * \version V2.0.0
  * \date    20/08/2016
  * \brief   This file contains all the required functions prototypes for the MSTN PORT firmware library.
  *
  * \warning THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, INTEC SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * \copyright COPYRIGHT 2017 Intec Group
  */

#ifndef __mstn_port_h
#define __mstn_port_h

#include "mstn_types.h"
#include "MDR32F9Qx_port.h"
#include "MDR32Fx.h"
#include "mstn.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef struct{
    uint32_t mask;
    uint8_t shift;
    PORT_InitTypeDef *initStruct;
    MDR_PORT_TypeDef *port;
    uint32_t availableModes;
}_PinBaseInfo;

volatile _PinBaseInfo pinsInfoMass[MAX_PIN_NUM + 1];
volatile uint32_t *pinsRxTxReg[MAX_PIN_NUM+1];
volatile _PinMode pinsMode[MAX_PIN_NUM+1];

#define OE_REG_SHIFT                    (1)
#define FUNC_REG_SHIFT                  (2)
#define ANALOG_REG_SHIFT                (3)
#define PULL_REG_SHIFT                  (4)

#define PINMASK_FAST(pin)               (*(uint32_t*)(&pinsInfoMass[pin]))
#define SET_OE_OUT(pin)                 (*(pinsRxTxReg[pin] + OE_REG_SHIFT)|= PINMASK_FAST(pin))
#define SET_OE_IN(pin)                  (*(pinsRxTxReg[pin] + OE_REG_SHIFT)&=~PINMASK_FAST(pin))
#define SET_PIN_DIG_MODE(pin)           (*(pinsRxTxReg[pin] + ANALOG_REG_SHIFT)|= PINMASK_FAST(pin))
#define SET_PIN_ANALOG_MODE(pin)        (*(pinsRxTxReg[pin] + ANALOG_REG_SHIFT)&=~PINMASK_FAST(pin))
#define SET_PIN_PORT_FUNC(pin)          (*(pinsRxTxReg[pin] + FUNC_REG_SHIFT)&= ~(0b11 << (pinsInfoMass[pin].shift * 2)))
#define RESET_PULLS(pin)                { *(*(pinsRxTxReg + pin) + PULL_REG_SHIFT)&= ~(PINMASK_FAST(pin) << 16); \
                                          *(*(pinsRxTxReg + pin) + PULL_REG_SHIFT)&= ~(PINMASK_FAST(pin)); }

_ErrorStatus PORT_SetPinMode(int pinNum, _PinMode mode);
void PORT_PreInitAllGPIO( void );

#ifdef __cplusplus
}
#endif

#endif /* __mstn_port_h */
