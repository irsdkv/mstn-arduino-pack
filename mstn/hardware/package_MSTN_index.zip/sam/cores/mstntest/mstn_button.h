/*!
  * \file    mstn_button.h
  * \author  Intec Group
  * \version V2.0.0
  * \date    14/10/2016
  * \brief   This file contains all the required functions prototypes for the MSTN Button firmware library.
  *
  * \warning THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, INTEC SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * \copyright COPYRIGHT 2017 Intec Group
*/

#ifndef __mstn_button_h
#define __mstn_button_h

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SCHEMATIC_V02
#define BTN_BUTTON_PIN_NUM     (E18)
#else
#define BTN_BUTTON_PIN_NUM     (E13)
#endif

typedef enum {
    RELEASED = 0,
    PRESSED = 1
}_ButtonValue;

/*!
 * \brief   Инициализирует пин кнопки как цифровой вход с подтяжкой к питанию.
 * \param   Нет
 * \retval  Нет
 */
void BTN_UserButtonInit( void );

/*!
 * \brief   Читает состояние линии ввода кнопки.
 * \param   Нет
 * \retval  int 
 *          \arg RELEASED если не нажата 
 *          \arg PRESSED если нажата.
 */
int BTN_UserButtonRead( void );

void BTN_UserButtonDeinit(void);

#ifdef __cplusplus
}
#endif

#endif /* __mstn_button_h */

