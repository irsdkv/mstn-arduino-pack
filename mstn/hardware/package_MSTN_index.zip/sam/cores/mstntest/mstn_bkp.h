/*!
  * \file    mstn_bkp.h
  * \author  Intec Group
  * \version V2.0.0
  * \date    16/09/2016
  * \brief   This file contains all the required functions prototypes for the MSTN BKP firmware library.
  *
  * \warning THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, INTEC SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * \copyright COPYRIGHT 2017 Intec Group
*/

#ifndef __mstn_bkp_h
#define __mstn_bkp_h

#ifdef __cplusplus
extern "C" {
#endif

void BKP_SetRiAndLow( void );

#ifdef __cplusplus
}
#endif

#endif /* __mstn_bkp_h */

