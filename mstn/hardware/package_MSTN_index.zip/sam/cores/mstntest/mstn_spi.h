/*!
  * \file    mstn_spi.h
  * \author  Intec Group
  * \version V2.0.0
  * \date    15/10/2016
  * \brief   This file contains all the required functions prototypes for the MSTN SPI firmware library.
  *
  * \warning THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, INTEC SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * \copyright COPYRIGHT 2017 Intec Group
  */

#ifndef __mstn_spi_h
#define __mstn_spi_h

#include "mstn_types.h"

#ifdef __cplusplus
extern "C" {
#endif

#define SPI1_SS_PIN     (D10)
#define SPI1_MOSI_PIN   (D11)
#define SPI1_MISO_PIN   (D12)
#define SPI1_SCK_PIN    (D13)
    
#define SPI2_SS_PIN     (A1)
#define SPI2_MOSI_PIN   (A2)
#define SPI2_MISO_PIN   (A0)
#define SPI2_SCK_PIN    (A3)

typedef enum{
    SPI1 = 0,
    SPI2 = 1
}_SPI_InterfaceNum;    ///< Номер интерфейса SPI.

typedef enum{
    SPI_MODE0 = 0x00,
    SPI_MODE1 = 0x04,
    SPI_MODE2 = 0x08,
    SPI_MODE3 = 0x0C,
}_SPI_Mode;        ///< Режим работы интерфейса SPI.

typedef enum{
    SPI_WL4 = 3,
    SPI_WL5 = 4,
    SPI_WL6 = 5,
    SPI_WL7 = 6,
    SPI_WL8 = 7,
    SPI_WL9 = 8,
    SPI_WL10 = 9,
    SPI_WL11 = 10,
    SPI_WL12 = 11,
    SPI_WL13 = 12,
    SPI_WL14 = 13,
    SPI_WL15 = 14,
    SPI_WL16 = 15
}_SPI_WordLen;     ///< Длина кадра обмена в битах.

/*!
 * \brief   Инициирует шину interfaceNum в режиме ведущего, 
 *          со скоростью, равной 16/divider [МГц], в режиме mode
 *          и длиной кадра wordLen бит.
 * \details Выводы инициализируются автоматически.
 * \param   interfaceNum - интерфейс SPI.
 *          Этот параметр может принимать следующие значения:
 *              \arg SPI1
 *              \arg SPI2
 * \param   mode - режим работы интерфейса SPI.
 *          Этот параметр может принимать следующие значения:
 *              \arg SPI_MODE0
 *              \arg SPI_MODE1
 *              \arg SPI_MODE2
 *              \arg SPI_MODE3
 * \param   wordLen - Длина кадра в битах.
 *          Этот параметр может принимать следующие значения:
 *              \arg SPI_WL4
 *              \arg SPI_WL5
 *              \arg SPI_WL6
 *              \arg SPI_WL7
 *              \arg SPI_WL8
 *              \arg SPI_WL9
 *              \arg SPI_WL10
 *              \arg SPI_WL11
 *              \arg SPI_WL12
 *              \arg SPI_WL13
 *              \arg SPI_WL14
 *              \arg SPI_WL15
 *              \arg SPI_WL16
 * \param   divider - Делитель частоты. Этот параметр не может быть не менее 1-го и более 256-и.
 * \retval  Нет
 */
void SPI_Begin(_SPI_InterfaceNum interfaceNum, _SPI_Mode mode, _SPI_WordLen wordLen, int divider);

/*!
 * \brief   Устанавливает значение делителя в divider на интерфейсе interfaceNum.
 * \details Частота обмена будет равна 40/divider [МГц].
 * \param   interfaceNum - интерфейс SPI.
 *          Этот параметр может принимать следующие значения:
 *              \arg SPI1
 *              \arg SPI2
 * \param   divider - Делитель частоты. Этот параметр не может быть менее 1-го и более 256-и.
 * \retval  Нет
 */
void SPI_SetClockDivider(_SPI_InterfaceNum interfaceNum, int divider);

/*!
 * \brief   Осуществляет передачу слова данных по шине SPI, 
 *          одновременно принимая входящую информацию.
 * \param   interfaceNum - интерфейс SPI.
 *          Этот параметр может принимать следующие значения:
 *              \arg SPI1
 *              \arg SPI2
 * \param   word - Слово для передачи. Если длина кадра при инициализации интерфейса установлена меньше
 *                 SPI_WL16 - будут переданы только первые N бит, где N - длина кадра, заданная при
 *                 инициализации интерфейса.
 * \retval  Принятое слово. -1, если данных принято не было. 
 *                 Если длина кадра при инициализации интерфейса установлена меньше
 *                 SPI_WL16 - будут приняты только первые N бит, где N - длина кадра, заданная при
 *                 инициализации интерфейса.
 */
int SPI_Transfer(_SPI_InterfaceNum interfaceNum, uint16_t word);

/*!
 * \brief   Деинициализирует интерфейс interfaceNum, не изменяя режим работы выводов,
 *          принимавших участие в обмене.
 * \param   interfaceNum - интерфейс SPI.
 *          Этот параметр может принимать следующие значения:
 *              \arg SPI1
 *              \arg SPI2
 * \retval  Нет
 */
void SPI_End(_SPI_InterfaceNum interfaceNum);

#ifdef __cplusplus
}
#endif

#endif /* __mstn_spi_h */
