/*!
  * \file    mstn_led.h
  * \author  Intec Group
  * \version V2.0.0
  * \date    25/08/2016
  * \brief   This file contains all the required functions prototypes for the MSTN LED firmware library.
  *
  * \warning THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, INTEC SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * \copyright COPYRIGHT 2017 Intec Group
  */

#ifndef __mstn_led_h
#define __mstn_led_h

#include "mstn_types.h"

#ifdef __cplusplus
extern "C" {
#endif

    
#ifdef SCHEMATIC_V02
#define LED_GRN_PINNUM      (E5)
#define LED_RED_PINNUM      (E7)
#else
#define LED_GRN_PINNUM      (E4)
#define LED_RED_PINNUM      (E6)
#endif

typedef enum {
    TURN_OFF = 0,
    TURN_ON = 1
}_LED_State;

/*!
 * \brief   Инициализирует выводы пользовательских светодиодов как цифровые выводы.
 * \details По умолчанию инициализирвоаны при входе в main().
 * \param   Нет
 * \retval  Нет
 */
void LED_Init( void );

/*!
 * \brief   Устанавливает состояние вывода пользовательского зеленого светодиода
 * \param   newState: Новое состояние.
 *          Этот параметр может принимать следующие значения:
 *              \arg TURN_OFF: Отключить питание.
 *              \arg TURN_ON: Подать питание.
 * \retval  Нет
 */
void LED_SetGreenState(uint8_t newState);

/*!
 * \brief   Управление яркостью светодиода с помощью ШИМ.
 * \details Частота ШИМ по умолчанию равна 1000Гц.
 *          После вызова функции PWM_BeginConfig() частота ШИМ 
 *          будет равна значению частоты, переданному в эту функцию.
 * \warning Внимание!
 *          Вывод D9 и вывод зеленого светодиода находятся на одном ШИМ канале.
 *          Таким образом, управляя светодиодом с помощью этой функции Вы так же
 *          управляете и ШИМ вывода D9 и наоборот.
 *          Вызов описываемой функции не переводит вывод D9 в ШИМ режим.
 * \param   val: Новое состояние.
 *          Этот параметр может принимать следующие значения:
 *              \arg 0 <= val <= 65535
 * \retval  Нет
 */
void LED_SetPwmGreen(int val);

/*!
 * \brief   Задать линию ввода-вывода зеленого светодиода как 
 *          выход компаратора (см. "mstn_comp.h").
 * \param   Нет
 * \retval  Нет
 */
void LED_SetGreenAsCompOut( void );

/*!
 * \brief   Задать линию ввода-вывода зеленого светодиода как 
 *          цифровой выход (аналогично эффекту функции LED_Init()
 *          для зеленого светодиода).
 * \param   Нет
 * \retval  Нет
 */
void LED_SetGreenAsDigitalOut( void );

/*!
 * \brief   Устанавливает состояние вывода пользовательского красного светодиода
 * \param   newState: Новое состояние.
 *          Этот параметр может принимать следующие значения:
 *              \arg TURN_OFF: Отключить питание.
 *              \arg TURN_ON: Подать питание.
 * \retval  Нет
 */
void LED_SetRedState(uint8_t newState);

#ifdef __cplusplus
}
#endif

#endif /* __mstn_led_h */
