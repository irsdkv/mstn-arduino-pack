/*!
  * \file    mstn_eeprom.h
  * \author  Intec Group
  * \version V2.0.0
  * \date    22/08/2016
  * \brief   This file contains all the required functions prototypes for the MSTN internal EEPROM firmware library.
  *
  * \warning THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, INTEC SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * \copyright COPYRIGHT 2017 Intec Group
*/

#ifndef __mstn_eeprom_h
#define __mstn_eeprom_h

#ifdef __cplusplus
extern "C" {
#endif

/*! Модуль mstn_eeprom.h предоставляет функции для работы с блоком (банком) информационной EEPROM памяти,
 * находящимся на чипе К1986ВЕ92QI. 
 * Объем этого блока составляет 4кБ и он отделен от памяти программ и данных.
 * Адрес начала блока - INFO_BANK_ADDRESS_START.
 * Адрес конца блока - INFO_BANK_ADDRESS_END (последний доступный байт находится по адресу (INFO_BANK_ADDRESS_END - 1))
 * При стирании блока, все ячейки памяти инициализируются значениями логических единиц (0b11111111 каждый байт).
 * При записи данных необходимые биты переходят в состояние лог. ноля и вернуть их в состояние лог. единицы 
 * возможно только процедурой стирания всего блока.
 * 
 * Пример:
 * После однократной записи байта 0b01010101 вернуть ячейки памяти из состояния лог. нулей
 * (биты 1,3,5,7 в данном примере, считая от ноля) в состояние лог. единицы невозможно без стирания всего блока памяти.
 * То есть после повторной записи (без стирания блока памяти) по тому же адресу памяти байта 0b11110000,
 * в данной ячейке информационной памяти будет значение 0b01010000 (результат лог. умножения байтов 0b01010101 и 0b11110000).
 * 
 */
#define INFO_BANK_ADDRESS_START     0x08000000
#define INFO_BANK_ADDRESS_END       0x08001000

/*!
 * \brief   Полностью очищает информационный банк памяти.
 * \param   Нет
 * \retval  Нет
 */
void EEPROM_EraseInfoBank( void );

/*!
 * \brief   Записывает байт в информационную EEPROM памяти.
 * \param   address - адрес, по которому будет записан байт.
 * \param   data - значение для записи.
 * \retval  int:
 *          \arg 1, если байт записан
 *          \arg 0, если нет (передан неверный адрес).
 */
int EEPROM_WriteByteInInfoBank(int address, unsigned char data);

/*!
 * \brief   Записывает массив байт в информационную EEPROM память, начиная с адреса startAddress.
 * \param   startAddress - начальный адрес для записи массива.
 * \param   buff - ссылка на начало массива байт для записи.
 * \param   len - длина массива.
 * \retval  int - количество записанных байт.
 */
int EEPROM_WriteBuffInInfoBank(int startAddress, const unsigned char * buff, int len);

/*!
 * \brief   Считывает байт из информационной EEPROM памяти.
 * \param   address - адрес, по которому будет произведена запись байта.
 * \retval  Считанное значение (если передан неверный адрес - возвращаемое значение - 0).
 */
unsigned char EEPROM_ReadByteFromInfoBank(int address);

/*!
 * \brief   Считывает байт из информационной EEPROM памяти.
 * \param   startAddress - адрес, с которого начнется чтение массива байтов.
 * \param   len - количество байтов для считывания.
 * \retval  int - количество считанных байтов.
 */
int EEPROM_ReadBuffFromInfoBank(int startAddress, unsigned char *buff, int len);

#ifdef __cplusplus
}
#endif

#endif /* __mstn_eeprom_h */
