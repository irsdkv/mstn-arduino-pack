/*!
  * \file    pins_arduino_w.h
  * \author  Intec Group
  * \version V2.0.0
  * \date    17/12/2016
  * \brief   This file contains wrappers to some Arduino variables.
  *
  * \warning THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, INTEC SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * \copyright COPYRIGHT 2017 Intec Group
  */

#ifndef PINS_ARDUINO_H
#define PINS_ARDUINO_H

#include <MDR32Fx.h>
#include "mstn_gpio.h"
#include "mstn_types.h"

#ifdef __cplusplus
extern "C" {
#endif

#define NUM_DIGITAL_PINS            20
#define NUM_ANALOG_INPUTS           6
#define analogInputToDigitalPin(p)  ((p < NUM_ANALOG_INPUTS) ? (p) + 14 : -1)
#define extendedPinToDigitalPin(p)  ((p) + NUM_DIGITAL_PINS)

#define digitalPinHasPWM(p)         ((p) == 1 || (p) == 4 || (p) == 6 || (p) == 7 || (p) == 8 || (p) == 9)

static const uint8_t SS   = D10;
static const uint8_t MOSI = D11;
static const uint8_t MISO = D12;
static const uint8_t SCK  = D13;

static const uint8_t SDA = E10;
static const uint8_t SCL = E11;

#ifdef SCHEMATIC_V02
#define LED_BUILTIN     (E5)
#else
#define LED_BUILTIN     (E4)
#endif

static const uint32_t PROGMEM port_to_mode_PGM[] = {
    (uint32_t) &MDR_PORTA->OE,
    (uint32_t) &MDR_PORTB->OE,
    (uint32_t) &MDR_PORTC->OE,
    (uint32_t) &MDR_PORTD->OE,
    (uint32_t) &MDR_PORTE->OE,
    (uint32_t) &MDR_PORTF->OE,
};

static const uint32_t PROGMEM port_to_output_PGM[] = {
    (uint32_t) &MDR_PORTA->RXTX,
    (uint32_t) &MDR_PORTB->RXTX,
    (uint32_t) &MDR_PORTC->RXTX,
    (uint32_t) &MDR_PORTD->RXTX,
    (uint32_t) &MDR_PORTE->RXTX,
    (uint32_t) &MDR_PORTF->RXTX,
};

static const uint32_t PROGMEM port_to_input_PGM[] = {
    (uint32_t) &MDR_PORTA->RXTX,
    (uint32_t) &MDR_PORTB->RXTX,
    (uint32_t) &MDR_PORTC->RXTX,
    (uint32_t) &MDR_PORTD->RXTX,
    (uint32_t) &MDR_PORTE->RXTX,
    (uint32_t) &MDR_PORTF->RXTX,
};

static const uint32_t PROGMEM analog_in_pin_to_bit_mask_PGM[] = {
    _BV(2),
    _BV(3),
    _BV(6),
    _BV(5),
    _BV(6),
    _BV(7),
};

static const uint32_t PROGMEM digital_pin_to_port_PGM[] = {
    PORTB, /* 0 */
    PORTB,
    PORTA,
    PORTA,
    PORTA,
    PORTA,
    PORTA,
    PORTA,
    PORTC, /* 8 */
    PORTB,
    PORTF,
    PORTF,
    PORTF,
    PORTF,
    PORTD, /* 14 */
    PORTD,
    PORTD,
    PORTD,
    PORTC,
    PORTC,
};

static const uint32_t PROGMEM digital_pin_to_bit_mask_PGM[] = {
    _BV(6), /* 0 */
    _BV(5),
    _BV(0),
    _BV(4),
    _BV(3),
    _BV(2),
    _BV(1),
    _BV(5),
    _BV(2), /* 8 */
    _BV(7),
    _BV(2),
    _BV(0),
    _BV(3),
    _BV(1),
    _BV(2), /* 14 */
    _BV(3),
    _BV(6),
    _BV(5),
    _BV(1),
    _BV(0),
};

static const uint8_t PROGMEM digital_pin_to_timer_PGM[] = {
    NOT_ON_TIMER,
    NOT_ON_TIMER,
    NOT_ON_TIMER,
    NOT_ON_TIMER,
    NOT_ON_TIMER,
    NOT_ON_TIMER,
    NOT_ON_TIMER,
    NOT_ON_TIMER,
    NOT_ON_TIMER,
    NOT_ON_TIMER,
    NOT_ON_TIMER,
    NOT_ON_TIMER,
    NOT_ON_TIMER,
    NOT_ON_TIMER,
    NOT_ON_TIMER,
    NOT_ON_TIMER,
    NOT_ON_TIMER,
    NOT_ON_TIMER,
    NOT_ON_TIMER,
    NOT_ON_TIMER,
};

// These serial port names are intended to allow libraries and architecture-neutral
// sketches to automatically default to the correct port name for a particular type
// of use.  For example, a GPS module would normally connect to SERIAL_PORT_HARDWARE_OPEN,
// the first hardware serial port whose RX/TX pins are not dedicated to another use.
//
// SERIAL_PORT_MONITOR        Port which normally prints to the Arduino Serial Monitor
//
// SERIAL_PORT_USBVIRTUAL     Port which is USB virtual serial
//
// SERIAL_PORT_LINUXBRIDGE    Port which connects to a Linux system via Bridge library
//
// SERIAL_PORT_HARDWARE       Hardware serial port, physical RX & TX pins.
//
// SERIAL_PORT_HARDWARE_OPEN  Hardware serial ports which are open for use.  Their RX & TX
//                            pins are NOT connected to anything by default.
#define SERIAL_PORT_MONITOR   ///<USB
#define SERIAL_PORT_HARDWARE  ///<USB

#ifdef __cplusplus
}
#endif

#endif /* PINS_ARDUINO_H */

