/*!
  * \file    arduino_w.h
  * \author  Intec Group
  * \version V2.0.0
  * \date    25/12/2016
  * \brief   This file contains wrappers to some Arduino variables and functions.
  *
  * \warning THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, INTEC SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * \copyright COPYRIGHT 2017 Intec Group
  */

#ifndef __arduino_h
#define __arduino_h
    
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include "mstn_types.h"
#include "MDR32Fx.h"
#include "binary.h"
#include "core_cm3.h"
#include "core_cmFunc.h"
#include "core_cmInstr.h"
#include "MDR32F9Qx_adc.h"
#include "MDR32F9Qx_bkp.h"
#include "MDR32F9Qx_board.h"
#include "MDR32F9Qx_comp.h"
#include "MDR32F9Qx_config.h"
#include "MDR32F9Qx_dac.h"
#include "MDR32F9Qx_eeprom.h"
#include "MDR32F9Qx_i2c.h"
#include "MDR32F9Qx_lib.h"
#include "MDR32F9Qx_port.h"
#include "MDR32F9Qx_power.h"
#include "MDR32F9Qx_rst_clk.h"
#include "MDR32F9Qx_ssp.h"
#include "MDR32F9Qx_timer.h"
#include "MDR32F9Qx_uart.h"
#include "MDR32F9Qx_usb.h"
#include "mstn.h"
#include "mstn_adc.h"
#include "mstn_bkp.h"
#include "mstn_button.h"
#include "mstn_clk.h"
#include "mstn_com.h"
#include "mstn_comp.h"
#include "mstn_control.h"
#include "mstn_dac.h"
#include "mstn_eeprom.h"
#include "mstn_eeprom_external.h"
#include "mstn_eeprom_super.h"
#include "mstn_external_interrupt.h"
#include "mstn_gpio.h"
#include "mstn_i2c.h"
#include "mstn_led.h"
#include "mstn_port.h"
#include "mstn_pwm.h"
#include "mstn_rtc.h"
#include "mstn_spi.h"
#include "mstn_syscalls.h"
#include "mstn_systick_interrupt.h"
#include "mstn_uart.h"
#include "mstn_usb.h"
#include "mstn_version.h"
#include "pins_mstn.h"
#include "system_MDR32F9Qx.h"


#ifdef __cplusplus
extern "C" {
#endif

#define PI              (3.1415926535897932384626433832795)
#define HALF_PI         (1.5707963267948966192313216916398)
#define TWO_PI          (6.283185307179586476925286766559)
#define DEG_TO_RAD      (0.017453292519943295769236907684886)
#define RAD_TO_DEG      (57.295779513082320876798154814105)
#define EULER           (2.718281828459045235360287471352)
    
#define min(a,b)        ((a)<(b)?(a):(b))
#define max(a,b)        ((a)>(b)?(a):(b))
#define abs(x)          ((x)>0?(x):-(x))
#define constrain       (amt,low,high) ((amt)<(low)?(low):((amt)>(high)?(high):(amt)))
#define round(x)        ((x)>=0?(long)((x)+0.5):(long)((x)-0.5))
#define radians(deg)    ((deg)*DEG_TO_RAD)
#define degrees(rad)    ((rad)*RAD_TO_DEG)
#define sq(x)           ((x)*(x))

#define interrupts()        do{   \
                                NVIC_EnableIRQ(TIMER1_IRQn);        \
                                NVIC_EnableIRQ(TIMER1_IRQn);        \
                                NVIC_EnableIRQ(TIMER2_IRQn);        \
                                NVIC_EnableIRQ(TIMER3_IRQn);        \
                                NVIC_EnableIRQ(EXT_INT4_IRQn);      \
                                NVIC_EnableIRQ(SysTick_IRQn);       \
                            }while(0)    
                                
                            
#define noInterrupts()      do{   \
                                NVIC_DisableIRQ(TIMER1_IRQn);       \
                                NVIC_DisableIRQ(TIMER1_IRQn);       \
                                NVIC_DisableIRQ(TIMER2_IRQn);       \
                                NVIC_DisableIRQ(TIMER3_IRQn);       \
                                NVIC_DisableIRQ(EXT_INT4_IRQn);     \
                                NVIC_DisableIRQ(SysTick_IRQn);      \
                            }while(0)

#define clockCyclesPerMicrosecond()     ( F_CPU / 1000000L )
#define clockCyclesToMicroseconds(a)    ( (a) / clockCyclesPerMicrosecond() )
#define microsecondsToClockCycles(a)    ( (a) * clockCyclesPerMicrosecond() )

#define lowByte(w)                      ((uint8_t) ((w) & 0xFF))
#define highByte(w)                     ((uint8_t) ((w) >> 8))

#define bitRead(value, bit)             (((value) >> (bit)) & 0x01)
#define bitSet(value, bit)              ((value) |= (1UL << (bit)))
#define bitClear(value, bit)            ((value) &= ~(1UL << (bit)))
#define bitWrite(value, bit, bitvalue)  (bitvalue ? bitSet(value, bit) : bitClear(value, bit))
#define bit(b)                          (1UL << (b))

#define INTERNAL
#ifndef boolean
#define boolean         bool 
#endif

typedef short unsigned int word;
typedef uint8_t byte;
typedef const char __FlashStringHelper;

#define _NOP()      do { __ASM volatile ("nop"); } while (0)

#define _BV(bit)    (1 << (bit))

#ifndef PROGMEM
        #define PROGMEM
#endif

#define	prog_char	char
#define	PGM_P		char *

#define NOT_ON_TIMER    0

#define NOT_A_PIN       0
#define NOT_A_PORT      0

#define NOT_AN_INTERRUPT    (-1)

#define pgm_read_byte(x)    ((uint8_t)*(x))
#define memcpy_P(...)       memcpy(__VA_ARGS__)
#define PSTR(x)             x

#define pgm_read_word_near(address_short)   ((uint16_t)(*(address_short)))
#define pgm_read_dword_near(address_int)    ((uint32_t)(*(address_int)))
#define pgm_read_word(address_short)        pgm_read_word_near((address_short))
#define pgm_read_dword(address_int)         pgm_read_dword_near((address_int))

#define digitalPinToPort(P)                 ( pgm_read_dword( digital_pin_to_port_PGM + (P) ) )
#define digitalPinToBitMask(P)              ( pgm_read_dword( digital_pin_to_bit_mask_PGM + (P) ) )
#define digitalPinToTimer(P)                ( pgm_read_dword( digital_pin_to_timer_PGM + (P) ) )
#define analogInPinToBit(P)                 (( pgm_read_dword( analog_in_pin_to_bit_mask_PGM + (P) ) ))

#define portOutputRegister(P)               ( (volatile uint32_t *)( pgm_read_dword( port_to_output_PGM + (P))) )
#define portInputRegister(P)                ( (volatile uint32_t *)( pgm_read_dword( port_to_input_PGM + (P))) )
#define portModeRegister(P)                 ( (volatile uint32_t *)( pgm_read_dword( port_to_mode_PGM + (P))) )

void _delay_ms(double __ms); 
void _delay_us(double __us);

/*!
 * \brief   Аналог Arduino функции delay(). 
 * \details Подробнее см. ProgramDelay() (mstn_clk.h).
 */
void delay(unsigned long ms);
/*!
 * \brief   Аналог Arduino функции delayMicroseconds(). 
 * \details Подробнее см. ProgramDelayMicroseconds() (mstn_clk.h).
 */
void delayMicroseconds(unsigned int us);

/*!
 * \brief   Аналог Arduino функции millis(). 
 * \details Подробнее см. RTC_millis() (mstn_rtc.h).
 */
unsigned long millis( void );
/*!
 * \brief   Аналог Arduino функции micros(). 
 * \details Подробнее см. RTC_micros() (mstn_rtc.h).
 */
unsigned long micros( void );

/*!
 * \brief   Аналог Arduino функции pulseIn(). 
 * \details Подробнее см. GPIO_PulseIn() (mstn_gpio.h).
 */
unsigned long pulseIn(uint8_t pin, uint8_t state, unsigned long timeout);
/*!
 * \brief   Аналог Arduino функции pulseInLong(). 
 * \details Подробнее см. GPIO_PulseIn() (mstn_gpio.h).
 */
unsigned long pulseInLong(uint8_t pin, uint8_t state, unsigned long timeout);

/*!
 * \brief   Аналог Arduino функции shiftOut(). 
 * \details Подробнее см. GPIO_ShiftOut_Slow() (mstn_gpio.h).
 */
void shiftOut(uint8_t dataPin, uint8_t clockPin, uint8_t bitOrder, uint8_t val);

/*!
 * \brief   Аналог Arduino функции shiftIn(). 
 * \details Подробнее см. GPIO_ShiftIn_Slow() (mstn_gpio.h).
 */
uint8_t shiftIn(uint8_t dataPin, uint8_t clockPin, uint8_t bitOrder);

/*!
 * \brief   Аналог Arduino функции pinMode(). 
 * \details Если переданный номер вывода 
 *          соответствует выводу аналогового порта и переданный 
 *          режим равен INPUT - вывод будет сконфигурирован как аналоговый вход.
 *          Чтобы сконфигурировать выводы аналогового порта как цифровые входы - 
 *          используйте функцию GPIO_PinMode() модуля mstn_gpio.h или pinMode_DigitalInput().
 * \param   pin: Номер вывода для установки.
 * \param   mode: Режим для установки.
 * \retval  Нет
 */
void pinMode(uint8_t pin, uint8_t mode);

/*!
 * \brief   Устанавливает вывод именно как цифровой выход, делая 
 *          это быстрее, чем функция pinMode().
 * \param   pin: Номер вывода для установки.
 * \param   mode: Режим для установки.
 * \retval  Нет
 */
void pinMode_DigitalOutput(uint8_t pin);

/*!
 * \brief   Устанавливает вывод именно как цифровой вход, делая 
 *          это быстрее, чем функция pinMode().
 * \param   pin: Номер вывода для установки.
 * \param   mode: Режим для установки.
 * \retval  Нет
 */
void pinMode_DigitalInput(uint8_t pin);

/*!
 * \brief   Аналог Arduino функции digitalWrite(). 
 * \details Устанавливает на пине, сконфигурированном как 
 *          цифровой выход или цифровой вход значение, переданное в параметр pinValue.
 *          Если режим работы пина на момент вызова данной функции DIGITAL_OUTPUT:
 *          на пине будет установлен переданный логический уровень.
 *          Если режим работы пина на момент вызова данной функции 
 *          DIGITAL_INPUT или DIGITAL_INPUT_PULLUP или DIGITAL_INPUT_PULLDOWN:
 *          если переданный val == 0 - будут сняты подтяжка пина к питанию или земле,
 *          если переданный val != 0 - будет установлена подтяжка пина к питанию.
 *          Если режим работы порта не равен ни одному из цифровых режимов - пин будет
 *          переведен в режим DIGITAL_OUTPUT и на нем будет установлено значение val.
 *          После вызова этой функции отладка по JTAG становится невозможна, однако её быстродействие
 *          несколько выше, чем у функции digitalWrite_JtagEn().
 * \param   pin: Номер вывода для установки.
 * \param   val: Значение для установки.
 *          Этот параметр может принимать следующие значения:
 *              \arg LOW: устанавливает логический ноль если вывод сконфигурирован как цифровой выход 
 *                  или отключает подтяжку вывода к питанию если вывод сконфигурирован как цифровой вход
 *              \arg HIGH: устанавливает логическую единицу если вывод сконфигурирован как цифровой выход
 *                  или устанавливает подтяжку вывода к питанию (3.3В), если вывод
 *                  сконфигурирован как цифровой вход.
 * \retval  Нет
 */
void digitalWrite(uint8_t pin, uint8_t val);

/*!
 * \brief   Аналог Arduino функции digitalWrite(). 
 * \details Устанавливает на пине, сконфигурированном как 
 *          цифровой выход или цифровой вход значение, переданное в параметр pinValue.
 *          Если режим работы пина на момент вызова данной функции DIGITAL_OUTPUT:
 *          на пине будет установлен переданный логический уровень.
 *          Если режим работы пина на момент вызова данной функции 
 *          DIGITAL_INPUT или DIGITAL_INPUT_PULLUP или DIGITAL_INPUT_PULLDOWN:
 *          если переданный val == 0 - будут сняты подтяжка пина к питанию или земле,
 *          если переданный val != 0 - будет установлена подтяжка пина к питанию.
 *          Если режим работы порта не равен ни одному из цифровых режимов - пин будет
 *          переведен в режим DIGITAL_OUTPUT и на нем будет установлено значение val.
 * \param   pin: Номер вывода для установки.
 * \param   val: Значение для установки.
 *          Этот параметр может принимать следующие значения:
 *              \arg LOW: устанавливает логический ноль если вывод сконфигурирован как цифровой выход 
 *                  или отключает подтяжку вывода к питанию если вывод сконфигурирован как цифровой вход
 *              \arg HIGH: устанавливает логическую единицу если вывод сконфигурирован как цифровой выход
 *                  или устанавливает подтяжку вывода к питанию (3.3В), если вывод
 *                  сконфигурирован как цифровой вход.
 * \retval  Нет
 */
void digitalWrite_JtagEn(uint8_t pin, uint8_t val);

/*!
 * \brief   Аналог Arduino функции digitalRead().
 */
int digitalRead(uint8_t pin);

/*!
 * \brief   Аналог Arduino функции analogRead().
 * \param   pin: Номер вывода для чтения. В версии платы V0.2 необходимо 
 *               пользоваться значениями A0, A1, A2, A3, A4, A5 для pin-to-pin
 *               совместимости с Arduino.
 * \retval  int - от 0 (0.0В) до 1024(3.3В).
 */
int analogRead(uint8_t pin);

/*!
 * \brief   Аналог Arduino функции analogWrite().
 * \details Частота ШИМ при вызове функции не изменяется.
 * \param   pin: Номер вывода для чтения. В версии платы V0.2 необходимо 
 *               пользоваться значениями A0, A1, A2, A3, A4, A5 для pin-to-pin
 *               совместимости с Arduino.
 * \retval  uint8_t - от 0 (0.0В) до 255(3.3В).
 */
void analogWrite(uint8_t pin, uint8_t value);

/*!
 * \brief   Аналог Arduino функции map().
 */
long map(long x, long in_min, long in_max, long out_min, long out_max);

#include "pins_arduino_w.h"

#ifdef __cplusplus
}
#endif

#ifdef __cplusplus

inline uint16_t makeWord(uint16_t w)
{
    return w; 
}

inline uint16_t makeWord(uint8_t h, uint8_t l)
{
    return (h << 8) | l; 
}

#define word(...) makeWord(__VA_ARGS__)

#endif

#include "pins_arduino_w.h"

#endif /* __arduino_h */
