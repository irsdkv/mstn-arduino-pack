/*!
  * \file    mstn_uart.h
  * \author  Intec Group
  * \version V2.0.0
  * \date    17/02/2017
  * \brief   This file contains all the required functions prototypes for the MSTN UART firmware library.
  *
  * \warning THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, INTEC SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * \copyright COPYRIGHT 2017 Intec Group
  */

#ifndef __mstn_uart_h
#define __mstn_uart_h

#include "mstn_types.h"

#ifdef __cplusplus
extern "C" {
#endif

#define UARTBUFFLEN         (128)

#define SERIAL1_RX_PIN      (D0)
#define SERIAL1_TX_PIN      (D1)

#define SERIAL2_RX_PIN      (D11)
#define SERIAL2_TX_PIN      (D13)

#ifdef SCHEMATIC_V02
#define SERIAL3_RX_PIN      (E10)
#define SERIAL3_TX_PIN      (E9)
    
#define SERIAL4_RX_PIN      (E21)
#define SERIAL4_TX_PIN      (E19)
#else
#define SERIAL3_RX_PIN      (E9)
#define SERIAL3_TX_PIN      (E8)
    
#define SERIAL4_RX_PIN      (E12)
#define SERIAL4_TX_PIN      (E14)
#endif

#define STOPBITS_OFFS       (0)
#define STOPBITS_1          (0)
#define STOPBITS_2          (1)
    
#define PARITY_OFFS         (2)
#define PARITY_NONE         (0)
#define PARITY_EVEN         (1)
#define PARITY_ODD          (2)

#define WORDLEN_OFFS        (4)
    
#define WORDLEN_5b          (0)
#define WORDLEN_6b          (1)
#define WORDLEN_7b          (2)
#define WORDLEN_8b          (3)


#define UART_ERR_OE          (0x00000400)    ///< Переполнение буфера
#define UART_ERR_BE          (0x00000200)    ///< Прерывание приема – разрыв линии
#define UART_ERR_PE          (0x00000100)    ///< Ошибка контроля четности
#define UART_ERR_FE          (0x00000080)    ///< Ошибка в структуре кадра

typedef enum{
    SERIAL_5N1 = (WORDLEN_5b << WORDLEN_OFFS) | (PARITY_NONE << PARITY_OFFS) | (STOPBITS_1 << STOPBITS_OFFS),
    SERIAL_6N1 = (WORDLEN_6b << WORDLEN_OFFS) | (PARITY_NONE << PARITY_OFFS) | (STOPBITS_1 << STOPBITS_OFFS),
    SERIAL_7N1 = (WORDLEN_7b << WORDLEN_OFFS) | (PARITY_NONE << PARITY_OFFS) | (STOPBITS_1 << STOPBITS_OFFS),
    SERIAL_8N1 = (WORDLEN_8b << WORDLEN_OFFS) | (PARITY_NONE << PARITY_OFFS) | (STOPBITS_1 << STOPBITS_OFFS),  // the default
    SERIAL_5N2 = (WORDLEN_5b << WORDLEN_OFFS) | (PARITY_NONE << PARITY_OFFS) | (STOPBITS_2 << STOPBITS_OFFS),
    SERIAL_6N2 = (WORDLEN_6b << WORDLEN_OFFS) | (PARITY_NONE << PARITY_OFFS) | (STOPBITS_2 << STOPBITS_OFFS),
    SERIAL_7N2 = (WORDLEN_7b << WORDLEN_OFFS) | (PARITY_NONE << PARITY_OFFS) | (STOPBITS_2 << STOPBITS_OFFS),
    SERIAL_8N2 = (WORDLEN_8b << WORDLEN_OFFS) | (PARITY_NONE << PARITY_OFFS) | (STOPBITS_2 << STOPBITS_OFFS),
    SERIAL_5E1 = (WORDLEN_5b << WORDLEN_OFFS) | (PARITY_EVEN << PARITY_OFFS) | (STOPBITS_1 << STOPBITS_OFFS),
    SERIAL_6E1 = (WORDLEN_6b << WORDLEN_OFFS) | (PARITY_EVEN << PARITY_OFFS) | (STOPBITS_1 << STOPBITS_OFFS),
    SERIAL_7E1 = (WORDLEN_7b << WORDLEN_OFFS) | (PARITY_EVEN << PARITY_OFFS) | (STOPBITS_1 << STOPBITS_OFFS),
    SERIAL_8E1 = (WORDLEN_8b << WORDLEN_OFFS) | (PARITY_EVEN << PARITY_OFFS) | (STOPBITS_1 << STOPBITS_OFFS),
    SERIAL_5E2 = (WORDLEN_5b << WORDLEN_OFFS) | (PARITY_EVEN << PARITY_OFFS) | (STOPBITS_2 << STOPBITS_OFFS),
    SERIAL_6E2 = (WORDLEN_6b << WORDLEN_OFFS) | (PARITY_EVEN << PARITY_OFFS) | (STOPBITS_2 << STOPBITS_OFFS),
    SERIAL_7E2 = (WORDLEN_7b << WORDLEN_OFFS) | (PARITY_EVEN << PARITY_OFFS) | (STOPBITS_2 << STOPBITS_OFFS),
    SERIAL_8E2 = (WORDLEN_8b << WORDLEN_OFFS) | (PARITY_EVEN << PARITY_OFFS) | (STOPBITS_2 << STOPBITS_OFFS),
    SERIAL_5O1 = (WORDLEN_5b << WORDLEN_OFFS) | (PARITY_ODD  << PARITY_OFFS) | (STOPBITS_1 << STOPBITS_OFFS),
    SERIAL_6O1 = (WORDLEN_6b << WORDLEN_OFFS) | (PARITY_ODD  << PARITY_OFFS) | (STOPBITS_1 << STOPBITS_OFFS),
    SERIAL_7O1 = (WORDLEN_7b << WORDLEN_OFFS) | (PARITY_ODD  << PARITY_OFFS) | (STOPBITS_1 << STOPBITS_OFFS),
    SERIAL_8O1 = (WORDLEN_8b << WORDLEN_OFFS) | (PARITY_ODD  << PARITY_OFFS) | (STOPBITS_1 << STOPBITS_OFFS),
    SERIAL_5O2 = (WORDLEN_5b << WORDLEN_OFFS) | (PARITY_ODD  << PARITY_OFFS) | (STOPBITS_2 << STOPBITS_OFFS),
    SERIAL_6O2 = (WORDLEN_6b << WORDLEN_OFFS) | (PARITY_ODD  << PARITY_OFFS) | (STOPBITS_2 << STOPBITS_OFFS),
    SERIAL_7O2 = (WORDLEN_7b << WORDLEN_OFFS) | (PARITY_ODD  << PARITY_OFFS) | (STOPBITS_2 << STOPBITS_OFFS),
    SERIAL_8O2 = (WORDLEN_8b << WORDLEN_OFFS) | (PARITY_ODD  << PARITY_OFFS) | (STOPBITS_2 << STOPBITS_OFFS),
}_UART_Config;

typedef enum{
    SERIAL1 = 1,    ///< RX D0    TX D1
    SERIAL2 = 2,    ///< RX D11   TX D13
    SERIAL3 = 3,    ///< RX E9    TX E8
    SERIAL4 = 4     ///< RX E12   TX E14
}_UART_InterfaceNum;

/*!
 * \brief   Инициирует последовательное соединение и задает скорость передачи 
 *          данных в бит/c (бод). 
 * \details Распространенные значения скорости: 300, 1200, 2400, 4800, 9600, 14400, 19200, 28800, 
 *          38400, 57600 или 115200. Настройки выставляются по умолчанию: SERIAL_8N1 (8 значащих 
 *          бит в кадре, без контроля четности, 1 стоп-бит.)
 *          Одновременно могут использоваться максимум 2 интерфейса платы.
 *          Доступные комбинации:
 *             \arg SERIAL1, SERIAL2
 *             \arg SERIAL1, SERIAL4
 *             \arg SERIAL2, SERIAL3
 *             \arg SERIAL3, SERIAL4
 * \param   interfaceNum - номер интерфейса UART
 * \param   baud - Скорость передачи
 * \retval  Нет
 */
void UART_Begin(_UART_InterfaceNum interfaceNum, uint32_t baud);

/*!
 * \brief   Инициирует последовательное соединение и задает скорость передачи 
 *          данных в бит/c (бод). 
 * \details Дополнительно указываются параметры связи: кол-во битов, кол-во стоп битов, контроль четности в кадре.
 * \param   interfaceNum - номер интерфейса UART.
 * \param   baud - Скорость передачи.
 * \param   config - Дополнительные параметры связи.
 * \retval  Нет
 */
void UART_BeginConfig(_UART_InterfaceNum interfaceNum, uint32_t baud, _UART_Config config);

/*!
 * \brief   Деинициализирует интерфейс (линии вывода переключаются в состояние по умолчанию).
 * \param   interfaceNum - номер интерфейса UART.
 * \retval  Нет
 */
void UART_End(_UART_InterfaceNum interfaceNum);

/*!
 * \brief   Функция получает количество байт(символов) доступных для чтения из 
 *          последовательного интерфейса связи. 
 * \details Это те байты которые уже поступили и записаны 
 *          в буфер последовательного порта. Буфер может хранить до 128 байт, однако функция вернет
 *          общее количество байт, принятых после последнего обращения к функциям UART_Read() или
 *          UART_Peek(), даже если количество принятых байт превышает длину буфера (при этом доступными 
 *          будут только последние UARTBUFFLEN принятых байт). Таким образом можно отследить событие 
 *          переполнения буфера.
 * \param   interfaceNum - номер интерфейса UART.
 * \retval  Количество байт доступных для чтения.
 */
int UART_Available(_UART_InterfaceNum interfaceNum);

/*!
 * \brief   Функция считывает очередной доступный байт из буфера последовательного соединения.
 * \details Если при обращении к функции буфер приема переполнен, значение "количество доступных байт" сбрасывается к длине 
 *          буфера (т.е. следующее за этим обращение к функции UART_Available() вернет значение (UARTBUFFLEN - 1)).
 * \param   interfaceNum - номер интерфейса UART.
 * \retval  Следующий доступный байт или -1 если его нет.
 */
int UART_Read(_UART_InterfaceNum interfaceNum);

/*!
 * \brief   Возвращает следующий доступный байт (символ) из буфера входящего последовательно 
 *          соединения, не удаляя его из этого буфера. 
 * \details То есть успешный вызов этой функции 
 *          вернет тоже значение, что и следующий за ним вызов функции UART_Read().
 * \param   interfaceNum - номер интерфейса UART.
 * \retval  Следующий доступный байт или -1 если его нет.
 */
int UART_Peek(_UART_InterfaceNum interfaceNum);

/*!
 * \brief   Ожидает окончания передачи исходящих данных.
 * \param   interfaceNum - номер интерфейса UART.
 * \retval  Нет
 */
void UART_Flush(_UART_InterfaceNum interfaceNum);

/*!
 * \brief   Ожидает окончания приема посылки. Событие окончания приема возникает, 
 *          если на вход приемника не поступало новых данных в течение периода времени,
 *          необходимого для передачи 32 бит. 
 * \details Если в данный момент времени прием не ведется,
 *          то функция будет ожидать начала и окончания приема. Максимальное время ожидания 
 *          (в мкс.) задается во втором аргументе.
 * \warning Внимание! В случае, если длина принимаемой посылки будет больше длины буфера - 
 *          "лишние" байты в начале посылки будут утеряны.
 * \param   interfaceNum - номер интерфейса UART.
 * \param   maxWaitTime - максимальное время ожидания, мс. Если 0 - время ожидания 10сек.
 * \retval  Количество принятых данных (-1, если время ожидания истекло, но приема данных не было).
 */
int UART_Wait(_UART_InterfaceNum interfaceNum, uint32_t maxWaitTime);

/*!
 * \brief   Передает данные через последовательный порт как ASCII текст. 
 * \details Эта функция может принимать целые числа и выводить их соответствующими 
 *          им символами ASCII в соответствующей системе счисления.
 * \param   interfaceNum - номер интерфейса UART.
 * \param   var - Число для передачи.
 * \param   notation - Система счисления
 * \retval  Нет
 */
void UART_PrintInt(_UART_InterfaceNum interfaceNum, int var, _Notation notation);

/*!
 * \brief   Передает данные через последовательный порт как ASCII текст. 
 * \details Эта функция может принимать целые числа и выводить их соответствующими 
 *          им символами ASCII в соответствующей системе счисления с следующим за ним 
 *          символом возврата каретки (ASCII символ 13 или '\r') и символом новой строки (ASCII 10 или '\n')
 * \param   interfaceNum - номер интерфейса UART.
 * \param   var - Число для передачи.
 * \param   notation - Система счисления
 * \retval  Нет
 */
void UART_PrintlnInt(_UART_InterfaceNum interfaceNum, int var, _Notation notation);

/*!
 * \brief   printf() для интерфейса UART. Максимальный размер буфера 128 байт. 
 * \details https://msdn.microsoft.com/ru-ru/library/wc7014hz.aspx
 * \param   interfaceNum - номер интерфейса UART.
 * \retval  Нет
 */
void UART_PrintStr(_UART_InterfaceNum interfaceNum, const char*, ...);

/*!
 * \brief   Функция передает один байт как бинарный код через последовательное соединение.
 * \details Для того, чтобы передать данные как символы следует 
 *          использовать функцию UART_PrintInt() или UART_PrintStr().
 * \param   interfaceNum - номер интерфейса UART.
 * \retval  Нет
 */
void UART_Write(_UART_InterfaceNum interfaceNum, char c);

/*!
 * \brief   Функция передает данные как бинарный код через последовательное соединение.
 * \details Данные посылаются как серия байтов. Для того, чтобы 
 *          передать данные как символы следует использовать функцию 
 *          UART_PrintInt() или UART_PrintStr().
 * \param   interfaceNum - номер интерфейса UART.
 * \retval  Нет
 */
void UART_WriteBuff(_UART_InterfaceNum interfaceNum, char* buff, int len);

/*!
 * \brief   Функция возвращает 32-х битное значение с флагами ошибок, если таковые появились с 
 *          момента последнего к ней обращения. 
 * \details Возможные биты ошибок:
 *                              \arg UART_ERR_OE - Переполнение буфера
 *                              \arg UART_ERR_BE - Прерывание приема – разрыв линии
 *                              \arg UART_ERR_PE - Ошибка контроля четности
 *                              \arg UART_ERR_FE - Ошибка в структуре кадра
 * \param   interfaceNum - номер интерфейса UART.
 * \retval  Нет
 */
uint32_t UART_GetErrors(_UART_InterfaceNum interfaceNum);

#ifdef __cplusplus
}
#endif

#endif /* __mstn_uart_h */

