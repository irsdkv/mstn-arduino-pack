/*!
  * \file    mstn_syscalls.h
  * \author  Intec Group
  * \version V2.0.0
  * \date    17/02/2017
  * \brief   This file contains information about system calls which supportedin MSTN firmware library.
  *
  * \warning THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, INTEC SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * \copyright COPYRIGHT 2017 Intec Group
  */

#ifndef __mstn_syscalls_h
#define __mstn_syscalls_h

#ifdef __cplusplus
extern "C" {
#endif

/* СИСТЕМНЫЕ ВЫЗОВЫ */

/*! 
 * ПО, созданное на основе библиотек MSTNLib и стандартных библиотек ARM EMBEDDED TOOLCHAIN
 * предоставляет пользователю возможность использовать вызовы некоторых системных функций,
 * предоставляемых стандартной библиотекой libc.
 * Такими системными функциями являются, в частности:
 * 
 *      ----ФУНКЦИИ РАБОТЫ С ЧАСАМИ РЕАЛЬНОГО ВРЕМЕНИ-----
 *          В ПО, собранном с использованием библиотеки MSTNLib и библиотек GCC Arm Toolchain
 *          по умолчанию активируются часы реального времени (при наличии источника питания в батарейном домене
 *          часы реального времени будут "идти" и без основного питания после первого запуска такого ПО).
 *          Для установки текущего времени и работы с ним Вы можете использовать следующие функции стандартной библиотеки Си:
 * Заголовочный файл "sys/time.h":
 * int gettimeofday(struct timeval *tv, struct timezone *tz); // см. https://www.opennet.ru/man.shtml?topic=settimeofday&category=2&russian=0
 * int settimeofday(const struct timeval * tv, const struct timezone * tz);    // см. https://www.opennet.ru/man.shtml?topic=settimeofday&category=2&russian=0
 * 
 * Заголовочный файл "time.h":
 * time_t time( time_t * timeptr ) // см. http://cppstudio.com/post/597/
 * clock_t clock( void ); // см. http://cppstudio.com/post/561/
 * 
 *      ----ФУНКЦИИ СТАНДАРТНОГО ВВОДА/ВЫВОДА----
 * Заголовочный файл "stdio.h":
 * int printf(const char *format, ...); // Данная функция отправляет данные на ПК по интерфейсу USB.
 *                                      // Для приема данных на ПК используйте Client или
 *                                      // терминал плагина NetBeans.
 *                                      // Используется построчная буферизация, всвязи с этим для отправки
 *                                      // данных на ПК необходимо вставить после данных символ новой строки '\n'.
 *                                      // Размер буфера составляет 255 символов.
 * 
 * int scanf(const char *format, ...);  // Данная функция принимает данные с ПК по интерфейсу USB.
 *                                      // Для отправки строки данных используйте Client или
 *                                      // терминал плагина NetBeans.
 *                                      // Размер буфера составляет 255 символов.
 *                                      // Внимание!
 *                                      // 1) При отсутствии связи с ПК функция scanf() будет 
 *                                      // возвращать (-1), значения же, которые она 
 *                                      // поместит в затребованные переменные - не определены, что может привести к 
 *                                      // некорректному поведению программы. Рекомендуется всегда проверять 
 *                                      // возвращаемое значение функции scanf().
 *                                      // 2) Не помещайте вызовы этой функции одновременно в более чем один
 *                                      // поток программы (т.е. если Вы используете вызов этой функции
 *                                      // в основном контексте выполнения программы - не помещайте её вызов в прерывания.
 *                                      // В случае, если вызов scanf в прерывании произойдет до того,
 *                                      // как пользователь введет ответ на scanf основного контекста - поведение программы 
 *                                      // будет некорректно.
 *                                      // Однако, если Вы предпочитаете рисковать - вот пример для минимизации коллизии:
 *                                      // 
 *                                      //  if (scanf("%d", &changeMy) == 0) 
 *                                      //  {
 *                                      //      printf("Input error!\n");
 *                                      //      fseek(stdin,0,SEEK_END);
 *                                      //  }
 * 
 * 
 */

#ifdef __cplusplus
}
#endif

#endif /* __mstn_syscalls_h */
