/*!
  * \file    mstn_comp.h
  * \author  Intec Group
  * \version V2.0.0
  * \date    15/12/2016
  * \brief   This file contains all the required functions prototypes for the MSTN COMP firmware library.
  *
  * \warning THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, INTEC SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * \copyright COPYRIGHT 2017 Intec Group
*/

#ifndef __mstn_comp_h
#define __mstn_comp_h

#include "mstn_types.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SCHEMATIC_V02
#define COMP_IN1_PINNUM     (E6)
#define COMP_IN2_PINNUM     (E8)
#define COMP_OUT_PINNUM     (E5)
#else
#define COMP_IN1_PINNUM     (E5)
#define COMP_IN2_PINNUM     (E7)
#define COMP_OUT_PINNUM     (E4)
#endif

typedef enum{
    COMP_INVERTED = 0,
    COMP_NONINVERTED = 1
}_COMP_Invert;

typedef enum{
    COMP_IN1_PIN = 0,           // COMP_IN1_PINNUM, from 0V to 3.6V (!MAX=3.6V!)
    COMP_IN1_VREF_00div24,      // About 0.00V
    COMP_IN1_VREF_01div24,      // About 0.14V
    COMP_IN1_VREF_02div24,      // About 0.28V
    COMP_IN1_VREF_03div24,      // About 0.41V
    COMP_IN1_VREF_04div24,      // About 0.55V
    COMP_IN1_VREF_05div24,      // About 0.69V
    COMP_IN1_VREF_08div32,      // About 0.83V
    COMP_IN1_VREF_09div32,      // About 0.93V
    COMP_IN1_VREF_10div32,      // About 1.03V
    COMP_IN1_VREF_11div32,      // About 1.13V
    COMP_IN1_VREF_12div32,      // About 1.24V
    COMP_IN1_VREF_13div32,      // About 1.34V
    COMP_IN1_VREF_14div32,      // About 1.44V
    COMP_IN1_VREF_15div32,      // About 1.55V
    COMP_IN1_VREF_16div32,      // About 1.65V
    COMP_IN1_VREF_17div32,      // About 1.75V
    COMP_IN1_VREF_18div32,      // About 1.86V
    COMP_IN1_VREF_19div32,      // About 1.96V
    COMP_IN1_VREF_20div32,      // About 2.06V
    COMP_IN1_VREF_21div32,      // About 2.17V
    COMP_IN1_VREF_22div32,      // About 2.27V
    COMP_IN1_VREF_23div32,      // About 2.37V
}_COMP_IN1_Source;

/*!
 * \brief   Инициализирует модуль компаратора в соответствии с переданными настройками.
 * \details Инициализация выводов производится автоматически в соответствии с переданными параметрами.
 *          Для инициализации вывода зеленого светодиода как индикатора выхода компаратора 
 *          используйте функцию LED_SetGreenAsCompOut() (см. "mstn_led.h").
 * \param   inversion:
 *       \arg COMP_NONINVERTED: Неинвертированный выход: 
 *              Выход = TRUE если IN1 > IN2 (source == COMP_IN1_PIN) 
 *              или COMP_VREF > IN2 (source != COMP_IN1_PIN),
 *              иначе FALSE.
 *        \arg COMP_INVERTED: Инвертированный выход: Выход = FALSE если IN1 > IN2 (source == COMP_IN1_PIN)
 *              или COMP_VREF > IN2 (source != COMP_IN1_PIN),
 *              иначе TRUE.
 * \param   source: Сигнал, поступающий на канал компаратора IN1. Значения см. _COMP_IN1_Source
 * \retval  Нет
 */
void COMP_Begin(_COMP_Invert inversion, _COMP_IN1_Source source);

/*!
 * \brief   Возвращает выходное состояние компаратора.
 * \param   Нет
 * \retval  bool
 */
bool COMP_GetCompOutValue( void );

/*!
 * \brief   Деинициализирует модуль компаратора. 
 * \details Все выводы, задействованные в его работе
 *          как входы инициализируются как DIGITAL_IN, вывод выхода, если он инициализирован
 *          как выход компаратора функцией LED_SetGreenAsCompOut(), инициализируется как
 *          DIGITAL_OUT.
 * \param   Нет
 * \retval  Нет
 */
void COMP_End( void );

#ifdef __cplusplus
}
#endif

#endif /* __mstn_comp_h */

