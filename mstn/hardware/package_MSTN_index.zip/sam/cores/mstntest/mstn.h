/*!
  * \file    mstn.h
  * \author  Intec Group
  * \version V2.0.0
  * \date    17/02/2017
  * \brief   ---
  *
  * \warning THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, INTEC SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * \copyright COPYRIGHT 2017 Intec Group
  */

#ifndef MSTN_H
#define MSTN_H

#ifdef __cplusplus
extern "C" {
#endif

#define _VAL(addr)                              (*(addr))

#define _AS_UINT8_POINTER(addr)                 ((uint8_t*)(addr))
#define _AS_UINT16_POINTER(addr)                ((uint16_t*)(addr))
#define _AS_UINT32_POINTER(addr)                ((uint32_t*)(addr))
    
#define GPIO_SET(pin, val)                      _VAL(_VAL(pins_rxtx_bitband_addr + (pin))) = !!(val)
#define GPIO_GET(pin)                           _VAL(_VAL(pins_rxtx_bitband_addr + (pin)))
#define GPIO_SET_LOW(pin)                       _VAL(_VAL(pins_rxtx_bitband_addr + (pin))) = 0x0
#define GPIO_SET_HIGH(pin)                      _VAL(_VAL(pins_rxtx_bitband_addr + (pin))) = 0x1

#define SRAM_START_ADDR                         (0x20000000)
#define BIT_BAND_ALIAS_SRAM_BASE                (0x22000000)
    
#define PERIPHERAL_START_ADDR                   (0x40000000)
#define BIT_BAND_ALIAS_PERIPHERAL_BASE          (0x42000000)

#define BITBAND_BIT_ADDR(addr, bitnum)          (((addr) & 0xF0000000) + 0x2000000 + (((addr) & 0xFFFFF) << 5) + ((bitnum) << 2))
#define BITBAND_BIT_GET_VAL(addr, bitnum)       _VAL(_AS_UINT32_POINTER(BITBAND_BIT_ADDR(addr, bitnum))) 
#define BITBAND_BIT_SET_LOW(addr, bitnum)       _VAL(_AS_UINT32_POINTER(BITBAND_BIT_ADDR(addr, bitnum))) = 0x0 
#define BITBAND_BIT_SET_HIGH(addr, bitnum)      _VAL(_AS_UINT32_POINTER(BITBAND_BIT_ADDR(addr, bitnum))) = 0x1

#ifdef __cplusplus
}
#endif

#include "pins_mstn.h"

#endif /* MSTN_H */

