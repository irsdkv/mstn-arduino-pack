/*!
  * \file    mstn_gpio.h
  * \author  Intec Group
  * \version V2.0.0
  * \date    16/01/2017
  * \brief   This file contains all the required functions prototypes for the MSTN GPIO firmware library.
  *
  * \warning THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, INTEC SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * \copyright COPYRIGHT 2017 Intec Group
  */

#ifndef __mstn_gpio_h
#define __mstn_gpio_h

#include "mstn_types.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    LOW = 0,
    HIGH = 1
}_DigitalPinValue;

typedef enum {
    THREE_STATE = 0,
    PULL_DOWN = 1,
    PULL_UP = 2
}_PullResistor;

typedef enum {
    LSBFIRST = 0,
    MSBFIRST = 1
}_BitOrder;

/*!
 * \brief   Аналог pinMode(). Устанавливает режим работы вывода.
 * \param   pinNum: Номер вывода для установки.
 *                  Допустимый диапазон номеров - от D0 до E17.
 * \param   pinMode: Режим работы для установки.
 *          Этот параметр может принимать следующие значения:
 *              \arg DIGITAL_INPUT: Цифровой вход (подтяжек нет).
 *              \arg DIGITAL_INPUT_PULLUP: Цифровой вход (подтяжка к питанию).
 *              \arg DIGITAL_INPUT_PULLDOWN: Цифровой вход (подтяжка к земле).
 *              \arg DIGITAL_OUTPUT: Цифровой выход (подтяжек нет).
 *              \arg ANALOG_INPUT: аналоговый вход (только для выводов порта ANALOG ивыводов 1 и 2 порта EXTEND (при положении джампера JP1 в позиции ADC).
 * \retval  Нет
 */
void GPIO_PinMode(uint8_t pinNum, _PinMode pinMode);

/*!
 * \brief   Быстрая установка вывода как цифрового входа
 *          (подтягивающие сопротивления не сбрасываются).
 * \param   pinNum: Номер вывода для установки.
 *                  Допустимый диапазон номеров - от D0 до E17.
 * \retval  Нет
 */
void GPIO_ChangeDirection_Input(uint8_t pinNum);

/*!
 * \brief   Быстрая установка вывода как цифрового выхода
 *          (подтягивающие сопротивления не устанавливаются).
 * \param   pinNum: Номер вывода для установки.
 *                  Допустимый диапазон номеров - от D0 до E17.
 * \retval  Нет
 */
void GPIO_ChangeDirection_Output(uint8_t pinNum);

/*!
 * \brief   Возвращает текущий режим работы вывода.
 * \param   pinNum: Номер вывода для чтения.
 * \retval  _PinMode: текущий режим работы вывода (см. _PinMode)
 */
_PinMode GPIO_GetPinMode(uint8_t pinNum);

/*!
 * \brief   Устанавливает или отключает встроенные (номинал ок. 50кОм) 
 *          подтягивающие резисторы на заданном выводе платы.
 * \param   pinNum: Номер вывода для установки. Для успешной установки подтягивающего резистора,
 *                  вывод, на момент вызова этой функции должен находиться в одном из следующих режимов:
 *                  DIGITAL_INPUT, DIGITAL_INPUT_PULLUP, DIGITAL_INPUT_PULDOWN, 
 *                  EXT_INT_CHANGE, EXT_INT_FALLING_EDGE или EXT_INT_RISING_EDGE.
 *                  Допустимый диапазон номеров - от D0 до E17.
 * \param   _PullResistor: значение подтягивающих резисторов для установки.
 *          Этот параметр может принимать следующие значения:
 *              \arg THREE_STATE: подтяжек нет.
 *              \arg PULL_DOWN: подтяжка к земле.
 *              \arg PULL_UP: подтяжка к питанию.
 * \retval  Нет
 */
void GPIO_SetPull(uint8_t pinNum, _PullResistor pullMode);

/*!
 * \brief   Устанавливает на пине, сконфигурированном как 
 *          цифровой выход значение, переданное в параметр pinValue.
 * \details Отладка по JTAG становится недоступна.
 *          Быстродействие: бесконечный цикл инвертирования состояния вывода 
 *          генерирует меандр частотой 1.5МГц:
 *          \code{.cpp}   
 *          while (1) {
 *          GPIO_DigitalWrite(pinNum, HIGH);
 *          GPIO_DigitalWrite(pinNum, LOW);
 *          }
 *          \endcode
 * \param   pinNum: Номер вывода для установки.
 *                  Допустимый диапазон номеров - от D0 до E17.
 * \param   pinValue: Значение для установки.
 *          Этот параметр может принимать следующие значения:
 *              \arg 0: устанавливает логический ноль.
 *              \arg !0: устанавливает логическую единицу.
 * \retval  Нет
 */
void GPIO_DigitalWrite(uint8_t pinNum, uint8_t pinValue);

/*!
 * \brief   Устанавливает на пине, сконфигурированном как 
 *          цифровой выход значение, переданное в параметр pinValue.
 * \details Отладка по JTAG остается доступна.
 *          Быстродействие: бесконечный цикл инвертирования состояния вывода 
 *          генерирует меандр частотой 0.75МГц:
 *          \code{.cpp}
 *          while (1) {
 *          GPIO_DigitalWrite_JtagEn(pinNum, HIGH);
 *          GPIO_DigitalWrite_JtagEn(pinNum, LOW);
 *          }
 *          \endcode
 * \param   pinNum: Номер вывода для установки.
 *                  Допустимый диапазон номеров - от D0 до E17.
 * \param   pinValue: Значение для установки.
 *          Этот параметр может принимать следующие значения:
 *              \arg 0: устанавливает логический ноль.
 *              \arg !0: устанавливает логическую единицу.
 * \retval  Нет
 */
void GPIO_DigitalWrite_JtagEn(uint8_t pinNum, uint8_t pinValue);

/*!
 * \brief   Возвращает логическое значение на выводе.
 * \details Функция возвращает значение бита данного вывода в регистре RXTX порта вывода. 
 *          Будьте уверены, что установлен верный режим работы вывода и передан корректный номер вывода.
 * \param   pinNum: Номер вывода для чтения.
 *                  Допустимый диапазон номеров - от D0 до E17.
 * \retval  _DIGITAL_PIN_VALUE:
 *              \arg LOW - логический уровень на выводе - низкий.
 *              \arg HIGH - логический уровень на выводе - высокий.
 */
_DigitalPinValue GPIO_DigitalRead(uint8_t pinNum);

/*!
 * \brief   Выводит байт информации на порт вход/выхода последовательно (побитно). 
 * \details Вывод может осуществляться как с первого (левого), так и с последнего (правого) бита. 
 *          Каждый бит последовательно подается на заданный порт, после чего подается сигнал на 
 *          синхронизирующий порт вход/выход, информируя о доступности к считыванию бита.
 *          Средняя частота тактов: 
 *                          \arg 1.19МГц для порядка LSBFIRST
 *                          \arg 1.08МГц для порядка MSBFIRST
 * \param   dataPin: вывод, которому будет отправляться каждый бит из сдвигаемого байта данных.
 * \param   clockPin: тактовый вывод, который будет переключаться каждый раз, когда на выводе dataPin 
 *                    устанавливается корректное значение .
 * \param   bitOrder: используемая последовательность вывода бит. 
 *                    MSBFIRST (Most Significant Bit First) — слева или 
 *                    LSBFIRST (Least Significant Bit First) — справа.
 * \param   val: значение (байт) для вывода.
 * \retval  Нет
 */
void GPIO_ShiftOut(uint8_t dataPin, uint8_t clockPin, _BitOrder bitOrder, uint8_t val);

/*!
 * \brief   Выводит байт информации на порт вход/выхода последовательно (побитно). 
 * \details Вывод может осуществляться как с первого (левого), так и с последнего (правого) бита. 
 *          Каждый бит последовательно подается на заданный порт, после чего подается сигнал на 
 *          синхронизирующий порт вход/выход, информируя о доступности к считыванию бита.
 *          Средняя частота тактов - 517.8кГц.
 * \param   dataPin: вывод, которому будет отправляться каждый бит из сдвигаемого байта данных.
 * \param   clockPin: тактовый вывод, который будет переключаться каждый раз, когда на выводе dataPin 
 *                    устанавливается корректное значение .
 * \param   bitOrder: используемая последовательность вывода бит. 
 *                    MSBFIRST (Most Significant Bit First) — слева или 
 *                    LSBFIRST (Least Significant Bit First) — справа.
 * \param   val: значение (байт) для вывода.
 * \retval  Нет
 */
void GPIO_ShiftOut_Slow(uint8_t dataPin, uint8_t clockPin, _BitOrder bitOrder, uint8_t val);

/*!
 * \brief   Осуществляет побитовый сдвиг и считывание байта данных, начиная с 
 *          самого старшего (левого) или младшего (правого) значащего бита. 
 * \details Процесс считывания каждого бита заключается в следующем: тактовый 
 *          вывод переводится в высокий уровень, считывается очередной бит из 
 *          линии данных, после чего тактовый вывод сбрасывается в низкий уровень.
 *          Средняя частота тактов - 1.3МГц.
 * \param   dataPin:  вывод, с которого будет считываться каждый бит.
 * \param   clockPin: тактовый вывод, который будет переключаться при считывании с dataPin.
 * \param   bitOrder: используемая последовательность вывода бит. 
 *                    MSBFIRST (Most Significant Bit First) — слева или 
 *                    LSBFIRST (Least Significant Bit First) — справа.
 * \param   val: значение (байт) для вывода.
 * \retval  Нет
 */
unsigned char GPIO_ShiftIn(uint8_t dataPin, uint8_t clockPin, _BitOrder bitOrder);

/*!
 * \brief   Осуществляет побитовый сдвиг и считывание байта данных, начиная с 
 *          самого старшего (левого) или младшего (правого) значащего бита. 
 * \details Процесс считывания каждого бита заключается в следующем: тактовый 
 *          вывод переводится в высокий уровень, считывается очередной бит из 
 *          линии данных, после чего тактовый вывод сбрасывается в низкий уровень.
 *          Средняя частота тактов - 0.73МГц.
 * \param   dataPin:  вывод, с которого будет считываться каждый бит.
 * \param   clockPin: тактовый вывод, который будет переключаться при считывании с dataPin.
 * \param   bitOrder: используемая последовательность вывода бит. 
 *                    MSBFIRST (Most Significant Bit First) — слева или 
 *                    LSBFIRST (Least Significant Bit First) — справа.
 * \param   val: значение (байт) для вывода.
 * \retval  Нет
 */
unsigned char GPIO_ShiftIn_Slow(uint8_t dataPin, uint8_t clockPin, _BitOrder bitOrder);

/*!
 * \brief   Считывает длину сигнала на заданном порту (HIGH или LOW).                
 * \details Например, если задано считывание HIGH функцией GPIO_PulseIn(), 
 *          функция ожидает пока на заданном порту не появится HIGH в течение
 *          времени, заданного аргументом timeout (в мс). 
 *          Когда HIGH получен, включается таймер, который будет остановлен 
 *          когда на порту вход/выхода будет LOW. Функция GPIO_PulseIn() 
 *          возвращает длину сигнала в микросекундах. Функция возвращает 0, 
 *          если в течение заданного времени (таймаута) не был зафиксирован 
 *          сигнал на порту.
 * \param   pinNum: Номер вывода для чтения.
 * \param   value: Тип ожидаемого сигнала
 *              \arg LOW - низкий уровень
 *              \arg HIGH - высокий уровень
 * \param  timeout: время ожидания сигнала в микросекундах; если равен нолю - одна секунда.
 * \retval int32_t: продолжительность принятого сигнала в мкс. Если 0 - сигнал не зафиксирован.
 */
uint32_t GPIO_PulseIn(uint8_t pinNum, uint8_t value, uint32_t timeout);

/*!
 * \brief   Генерирует на линии pinNum порта DIGITAL сигнал — прямоугольную "волну", 
 *          заданной частоты и с 50% рабочим циклом. 
 * \details Длительность задается параметром,
 *          duration, (вызов функции noTone() может отключить сигнал досрочно). 
 *          К порту вход/выхода может быть подключен пьезо или другой динамик для 
 *          воспроизведения сигнала.
 * \warning ВНИМАНИЕ! Задействование этой функции отключает возможность генерировать ШИМ сигнал на 
 *          выводах таймера 3 (линии D1, D8, D9, A5 и на зеленом светодиоде) и деактивирует
 *          установленные внешние прерывания на этих выводах. 
 *          Чтобы активировать эти функции вновь - вызовите GPIO_NoTone()
 *          и активируйте внешние прерывания вновь.
 * \param   pinNum - номер пина порта DIGITAL.
 * \param   frequency - частота сигнала.
 * \param   duration - длительность (в мс).
 * \retval  Нет
 */
void GPIO_Tone(uint8_t pinNum, uint32_t frequency, uint32_t duration);

/*!
 * \brief   Выводит на соответствующий вывод сигнал высокого уровня заданной длительности.
 * \param   pinNum - Номер вывода для установки (должен быть инициализирован как цифровой выход).
 * \param   duration - Значение для установки продолжительности положительного сигнала в микросекундах.
 * \retval  Нет
 */
void GPIO_Shot(uint8_t pinNum, uint32_t duration);

/*!
 * \brief   Отключает генерацию сигнала, запущенную функцией GPIO_Tone.
 * \param   Нет
 * \retval  Нет
 */
void GPIO_NoTone( void );

#ifdef __cplusplus
}
#endif

#endif /* __mstn_gpio_h */

