/*!
  * \file    mstn_version.h
  * \author  Intec Group
  * \version V2.0.0
  * \date    17/02/2017
  * \brief   This file contains all the functions prototypes for the version firmware library.
  *
  * \warning THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, INTEC SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * \copyright COPYRIGHT 2017 Intec
  */

#ifndef __mstn_version_h
#define __mstn_version_h

#ifdef __cplusplus
extern "C" {
#endif

    typedef struct _mstn_version_t
    {
        unsigned int major;
        unsigned int minor;
        unsigned int build;
    } _mstn_version;
    
    typedef struct _mstn_serial_number_t
    {
        unsigned int serialNumber;
    } _mstn_serial_number;

/*!
 * \brief   Вернуть текущую версию библиотеки MSTN. 
 * \param   Нет
 * \retval  _mstn_version
 */
const _mstn_version * MSTN_GetLibVersion( void );
    
/*!
 * \brief   Вернуть текущую версию установленного загрузчика.
 * \param   Нет
 * \retval  _mstn_version
 */
const _mstn_version * MSTN_GetBootloaderVersion( void );
    
/*!
 * \brief   Вернуть серийный номер текущей платы (сохранен в загрузчике).
 * \param   Нет
 * \retval  _mstn_serial_number
 */
const _mstn_serial_number * MSTN_GetSerialNumber( void );

#ifdef __cplusplus
}
#endif

#endif /* __mstn_version_h */

