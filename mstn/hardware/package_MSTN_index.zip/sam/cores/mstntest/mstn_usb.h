/*!
  * \file    mstn_usb.h
  * \author  Intec Group
  * \version V2.0.0
  * \date    17/02/2017
  * \brief   This file contains all the required functions prototypes for the MSTN user-mode USB firmware library.
  *
  * \warning THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, INTEC SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * \copyright COPYRIGHT 2017 Intec Group
  */

#ifndef __mstn_usb_h
#define __mstn_usb_h

#include "mstn_types.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum {
    NOT_CONNECTED = 0,
    CONNECTED = 1
} _USB_DeviceState;

typedef enum {
    FORBIDDEN = 0,
    PERMITTED = 1
}_USB_TransferPermission;

typedef struct {
	uint8_t bRequestType;
	uint8_t bRequestSubType;
	uint8_t bValue;
	uint8_t bDataLength;
	uint8_t data[52];
}_USB_REQUEST, *_PUSB_REQUEST;

typedef struct {
	uint8_t bRequestType;
	uint8_t bRequestSubType;
	uint8_t bAnswerValue;
	uint8_t bDataLength;
	uint8_t data[52];
}_USB_REQUEST_ANSWER, *_PUSB_REQUEST_ANSWER;

typedef uint32_t (*isr_t)(uint32_t arg);

typedef void (*request_handler_t)(const _PUSB_REQUEST pRequest, _PUSB_REQUEST_ANSWER pRequestAnswer);

/*!
 * \brief   Проверка состояния USB соединения. 
 * \param   Нет
 * \retval  _USB_DeviceState:
 *              \arg NOT_CONNECTED - USB соединение не установлено.
 *              \arg CONNECTED - USB соединение установлено.
 */
_USB_DeviceState USB_CheckUsbState(void);

/*!
 * \brief   Проверка на готовность USB host к обмену данными по каналу пользователя.
 * \retval  _USB_TransferPermission:
 *              \arg PERMITTED - Обмен разрешен.
 *              \arg FORBIDDEN - Обмен не разрешен (нет соединения с mstn-m100-client.exe запущенного с 
 *                   аргументом -t или с NetBeans плагином).
 */
_USB_TransferPermission USB_GetStatus( void );

/*!
 * \brief   USB_printf - printf() для потока USB. Размер буфера 512 байт. 
 * \details https://msdn.microsoft.com/ru-ru/library/wc7014hz.aspx
 * \param   См. printf().
 * \retval  _ErrorStatus:
 *              \arg R_ERROR - USB соединение не установлено, произошла ошибка передачи или
 *                   нет связи с ПО на хост-машине.
 *              \arg R_SUCCESS - действие выполнено успешно.
 */
_ErrorStatus USB_printf(const char*, ...);

/*!
 * \brief   Очищает файл лога, если таковой ведется сеансе консольной утилиты mstn-m100-client.exe
 * \details Если логгирование не ведется - никакого действия выполнено не будет.
 * \param   Нет
 * \retval  _ErrorStatus:
 *              \arg R_ERROR - USB соединение не установлено, произошла ошибка передачи или
 *                   нет связи с ПО на хост-машине.
 *              \arg R_SUCCESS - действие выполнено успешно.
 */
_ErrorStatus USB_ClearLogFile(void);

/*!
 * \brief   scanf() для потока USB. Размер буфера 512 байт. 
 * \details https://msdn.microsoft.com/ru-ru/library/9y6s16x1.aspx
 * \param   См. scanf().
 * \retval  _ErrorStatus:
 *              \arg R_ERROR - USB соединение не установлено, нет связи с принимающим
 *                   ПО (mstn-m100-client.exe с аргументом -t или с NetBeans плагином) на USB host или произошла ошибка передачи.
 *              \arg R_SUCCESS - действие выполнено успешно.
 */
_ErrorStatus USB_scanf(const char *, ...);

/*!
 * \brief   Передача данных по интерфейсу USB. Скорость непосредственно 
 *          передачи данных по интерфейсу USB составляет около 0.5Мб/с.
 * \details Максимальное количество данных, отправляемых за один вызов этой 
 *          функции составляет 4кб.
 * \warning Внимание!
 *          Не помещайте вызовы этой функции одновременно в более чем один
 *          поток программы (т.е. если Вы используете вызов этой функции
 *          в основном потоке - не помещайте её вызов в прерывания.
 *          В случае, если вызов scanf в прерывании произойдет до того,
 *          как пользователь введет ответ на scanf основного потока - поведение программы 
 *          будет некорректно.
 * \param   *buff: указатель на адрес начала массива для передачи данных.
 * \param   length: количество символов для передачи. Должно быть в пределах от ноля до 4*1024.
 * \retval  _ErrorStatus:
 *              \arg R_ERROR - USB соединение не установлено, нет связи с принимающим
 *                   ПО (mstn-m100-client.exe с аргументом -t или с NetBeans плагином) на USB host или 
 *                   произошла ошибка передачи.
 *              \arg R_SUCCESS - действие выполнено успешно.
 */
_ErrorStatus USB_TransieveData(char *buff, uint16_t length);

/*!
 * \brief   Прием данных по интерфейсу USB.Скорость непосредственно 
 *          передачи данных по интерфейсу USB составляет около 0.5Мб/с.
 * \param   *buff: указатель на адрес начала массива для приема данных.
 * \param   bufferLen: Длина буфера в байтах. (При превышении длины буфера "лишние" данные не сохраняются,
 *          функция возвращает R_ERROR)
 * \param   receiveLen: указатель на переменную, в которую будет записано количество принятых байт.
 * \retval  _ErrorStatus:
 *              \arg R_ERROR - USB соединение не установлено, нет связи с ПО на хост-машине
 *                   или произошла ошибка передачи или количество принятых данных больше переданной длины буфера.
 *              \arg R_SUCCESS - действие выполнено успешно.
 */
_ErrorStatus USB_ReceiveData(char *buff, uint16_t bufferLen, int *receivedLen);

/*!
 * \brief   Запустить счетчик пакетов SOF (USB Host Start Of Frame, частота 1кГц).
 * \details SOF - это синхросигнал, который отсылает USB Хост ведомым устройствам.
 *          Его частота составляет 1кГц (один раз в миллисекунду).
 *          Вы можете, при активном подключении к USB хосту, с высокой точностью
 *          отсчитывать время с точностью 1мс.
 * \retval uint64_t - текущее значение счетчика.
 */
void USB_StartSofCounter( void );

/*!
 * \brief   Остановить счетчик SOF пакетов.
 * \retval  uint64_t - текущее значение счетчика.
 */
uint64_t USB_StopSofCounter( void );

/*!
 * \brief   Возвратить текущее значение счетчика SOF.
 * \retval  uint64_t - текущее значение счетчика.
 */
uint64_t USB_GetSofCounterValue( void );

/*!
 * \brief   Сбросить значение счетчика SOF.
 * \retval  uint64_t - текущее значение счетчика.
 */
uint64_t USB_ResetSofCounter( void );

/*!
 * \brief   Возвращает количество аргументов, декодированных в 
 *          последнем вызове USB_Scanf().
 * \retval int - количество аргументов.
 */
int8_t USB_GetArgsDecodedQuant( void );

/*!
 * \brief   Установить приоритет обработчика прерываний, вызываемых 
 *          с помощью функции MstnClient_CTRL.callInterrupt() ПК библиотеки MstnClient_CTRL.
 * \param   priority: приоритет прерывания, не может быть меньше 2-х и больше 7-ми (7 - наименьший приоритет).
 * \retval  Нет
 */
void USB_EnableUsbAttachedInterrupts(uint8_t priority);

/*!
 * \brief   Устанавливает функцию (обработчик прерывания), которая будет 
 *          вызываться по интерфейсу USB, с помощью функции 
 *          MstnClient_CTRL.callInterrupt() ПК библиотеки Client.
 * \details В качестве обработчика используется обработчик внешнего 
 *          прерывания EXT_INT4, вывод которого не присутствует на корпусе МК.
 * \param   isr: функция для вызова в прерывании.
 * \param   number: номер обработчика прерывания. Доступно 4 функции для обработки прерываний, они
 *                  будут вызываться внутри обработчика EXT_INT4.
 *                  Может иметь значение от 0 до 3-х.
 * \retval  Нет
 */
void USB_AttachInterruptFromUsb(isr_t isr, uint8_t number);

/*!
 * \brief   Устанавливает функцию (обработчик прерывания), которая будет 
 *          вызываться по интерфейсу USB, с помощью функции 
 *          MstnClient_CTRL.callRequestHandler() ПК библиотеки MstnClient_CTRL.
 * \details В качестве обработчика используется обработчик внешнего 
 *          прерывания EXT_INT4, вывод которого не присутствует на корпусе МК.
 * \param   isr: функция для вызова в прерывании.
 * \retval  Нет
 */
void USB_AttachRequestHandler(request_handler_t request_handler);

/*!
 * \brief   Установить приоритет обработчика прерываний, вызываемых 
 *          с помощью функции MstnClien_CTRL.callInterrupt() ПК библиотеки Client.
 * \param   priority: приоритет прерывания, не может быть меньше 2-х и больше 7-ми (7 - наименьший приоритет).
 * \retval  Нет
 */
void USB_EnableUsbRequests(uint8_t priority);

/*!
 * \brief   возвращает количество прининятых 
 *          в последней передаче данных.
 * \param   Нет
 * \retval  Нет
 */
uint16_t USB_GetReceivedLen(void);

_ErrorStatus USB_CheckReceiveCompleting();

#ifdef __cplusplus
}
#endif

#endif /* __mstn_usb_h */
