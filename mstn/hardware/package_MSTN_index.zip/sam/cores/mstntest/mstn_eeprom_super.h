/*!
  * \file    mstn_eeprom_super.h
  * \author  Intec Group
  * \version V2.0.0
  * \date    10/08/2016
  * \brief   This file contains all the required functions prototypes for the MSTN EEPROM_SUPER firmware library.
  *
  * \warning THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, INTEC SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * \copyright COPYRIGHT 2017 Intec Group
*/

#ifndef __mstn_eeprom_super_h
#define __mstn_eeprom_super_h

#ifdef __cplusplus
extern "C" {
#endif

#define START_ADDRESS           0x08000000 
#define USER_APP_START_ADDRESS  0x08003000  // При изменении не забудь изменить адрес перехода в mstn_boot.c __JumpToAddress()

#define FLASH_PAGE_LEN    0x00001000

void EEPROM_SUPER_FlashConfig( void );
void EEPROM_SUPER_Init( void );
void EEPROM_SUPER_ProgramMainBankPage(unsigned long adr, unsigned long sz, unsigned char *buf);
void EEPROM_SUPER_WriteKey( void );
void EEPROM_SUPER_EraseKey( void );
void EEPROM_SUPER_EraseMainDataPages(char count);
void EEPROM_SUPER_EraseMainDataPage(char num);
void EEPROM_SUPER_WriteWordInInfoBank(unsigned long adr, long unsigned int var);
void EEPROM_SUPER_WriteWordInMainBank(unsigned long adr, long unsigned int var);
int EEPROM_SUPER_ReadWordFromMainBank(unsigned long adr);
unsigned long int EEPROM_SUPER_ReadWordFromInfoBank(unsigned long adr);
void EEPROM_SUPER_EraseFirstUserMainDataPages( void );

#ifdef __cplusplus
}
#endif

#endif /* __mstn_eeprom_super_h */
