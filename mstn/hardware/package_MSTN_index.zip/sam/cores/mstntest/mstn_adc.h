/*!
  * \file    mstn_adc.h
  * \author  Intec Group
  * \version V2.0.0
  * \date    20/09/2016
  * \brief   This file contains all the required functions prototypes for the MSTN ADC firmware library.
  *
  * \warning THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, INTEC SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * \copyright COPYRIGHT 2017 Intec Group
*/

#ifndef __mstn_adc_h
#define __mstn_adc_h

#include "mstn_types.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef SCHEMATIC_V02
#define ADC_AREF_GND_PIN                (E19)
#define ADC_AREF_VCC_PIN                (E21)
#else
#define ADC_AREF_GND_PIN                (E14)
#define ADC_AREF_VCC_PIN                (E12)
#endif
    
#define ADC_PRESCALER_8                 (0x03) ///< Время преобразования составляет ок. 4мкс. Default.
#define ADC_PRESCALER_16                (0x04) ///< Время преобразования составляет ок. 6,7мкс.
#define ADC_PRESCALER_32                (0x05) ///< Время преобразования составляет ок. 13мкс.
#define ADC_PRESCALER_64                (0x06) ///< Время преобразования составляет ок. 23мкс.
#define ADC_PRESCALER_128               (0x07) ///< Время преобразования составляет ок. 47мкс. 
#define ADC_PRESCALER_256               (0x08) ///< Время преобразования составляет ок. 88мкс. 
#define ADC_PRESCALER_512               (0x09) ///< Время преобразования составляет ок. 176мкс. 
#define ADC_PRESCALER_1024              (0x0A) ///< Время преобразования составляет ок. 352мкс. 

typedef enum{
    DEFAULT = 1,        ///< Опорное напряжение по умолчанию, равное 3.3В
    EXTERNAL = 0        ///< В качестве опорного напряжения будет использоваться напряжение, приложенное к выводам AREF- и AREF+ (от 2.4В до 3.3В)
}_AnalogReference;

/*!
 * \brief   Перезапускает АЦП модуль с заданным предделителем тактовой частоты, 
 *          конфигурируя линии ввода-вывода (доступные для режима аналогового входа) 
 *          как аналоговые входы.
 * \details Опорным источником напряжения является питание контроллера (ок. 3.3В)
 *          Уровни проверки значений измерения (см. ADC_LevelCheckSet) 
 *          составляют:
 *          \arg  lowLevel = 0
 *          \arg  highLevel = 4096
 * \param   prescaler   предделитель частоты тактирования. Влияет на длительность АЦП преобразования,
 *                      выполняемого в функции ADC_AnalogRead(). Допустимые значения: 
 *                      от ADC_PRESCALER_8 до ADC_PRESCALER_1024.
 *                      Значение по умолчанию (на момент входа в функцию main())
 *                      составляет ADC_PRESCALER_8.
 * \retval  Нет
 */
void ADC_Begin(uint32_t prescaler);

/*!
 * \brief   Производит измерение на соответствующем выводе и возвращает его результат.
 * \details Примерная длительность преобразования (при предделителе частоты по умолчанию, равному 8)
 *          составляет примерно 4.1мкс. 
 * \warning Внимание! Предельное напряжение на линиях ввода-вывода - 4.0В.
 * \param   pinNum  Номер вывода для установки (порт по умолчанию равен PORT_ANALOG).
 *                  Для большего удобства MSTN в качестве замены Arduino, имеется возможность 
 *                  использовать значения A0, A2, A3, A4, A5 - в таком случае, для версии платы V0.2 
 *                  номер выбранного вывода не будет соответствовать номеру вывода
 *                  на шелкографии и будет соответствовать номерам аналоговых выводов Arduino.
 *                  В следующих версиях платы маркировка выводов на плате будет соответствовать маркировке Arduino.
 * \retval  Результат измерения. Диапазон значений: от 0=GND до 4096=Uопоры.
 * \retval  -1 если модуль АЦП не запущен, идентификатор вывода не корректен.
 */
int ADC_AnalogRead(uint8_t pinNum);

/*!
 * \brief   Запускает измерение на соответствующем выводе, не дожидаясь
 *          его завершения.
 * \details Для получения результата измерения используйте
 *          функцию ADC_GetResult()
 * \warning Внимание! Предельное напряжение на линиях ввода-вывода - 4.0В.
 * \param   pinNum Номер вывода для установки (порт по умолчанию равен PORT_ANALOG).
 * \retval   0 - номер вывода корректен и измерение запущено.
 * \retval   1 - номер вывода некорректен.
 */
int ADC_StartConversion(uint8_t pinNum);

/*!
 * \brief   Возвращает результат последнего измерения, запущенного с
 *          помощью функции ADC_StartConversion() (при необходимости
 *          ожидая завершения преобразования).
 * \param   Нет
 * \retval  >=0 - результат измерения.
 * \retval  -1  - измерение небыло запущено.
 */
int ADC_GetResult( void );

/*!
 * \brief   Выполняет установку опорного напряжения.
 * \warning Внимание! Предельный диапазон разности напряжений - 4.0В. Максимальный корректный - 3.3В.
 *          Минимальная разность напряжений опоры, при которой измерения будут корректны - 2.4В.
 * \param   reference: источник опорного напряжения.
 *          Этот параметр может принимать следующие значения:
 *              \arg DEFAULT: Опорное напряжение - питание контроллера (ок. 3.3В).
 *              \arg EXTERNAL: Опорное напряжение берется с выводов AREF-(EXTEND19) и AREF+(EXTEND21 или DIGITAL_AR)
 * \retval  Нет
 */
void ADC_AnalogReference(_AnalogReference reference);

/*!
 * \brief   Задает нижний и верхний уровни проверки значений измерения.
 * \param   lowLevel: нижний уровень напряжения. Может принимать значения от 0 до 4096.
 * \param   highLevel: нижний уровень напряжения. Может принимать значения от 0 до 4096.
 * \retval  _ErrorStatus:
 *          \arg R_ERROR - если модуль АЦП не запущен, значения уровней не входят в допустимый диапазон,
 *                       или если lowLevel > highLevel
 *          \arg R_SUCCESS - установка произведена.
 */
_ErrorStatus ADC_LevelCheckSet(int lowLevel, int highLevel);

/*!
 * \brief   Производит измерение на соответствующем выводе и возвращает 
 *                                     результат проверки. Если параметр analogReadResult 
 *                                     не равен NULL - сохраняет результат измерения по переданному адресу.
 * \param   pinNum: Номер вывода для измерения.
 * \retval  _ErrorStatus:
 *          \arg FALSE - передан неверный идентификатор пина ввода или результат измерения
 *                  НЕ ВЫХОДИТ за в заданный диапазон значений.
 *          \arg TRUE - результат измерения ВЫХОДИТ за в заданный диапазон значений.
 */
bool ADC_LevelCheckOutOfRange(uint8_t pinNum, int* analogReadResult);

#ifdef __cplusplus
}
#endif

#endif /* __mstn_adc_h */

