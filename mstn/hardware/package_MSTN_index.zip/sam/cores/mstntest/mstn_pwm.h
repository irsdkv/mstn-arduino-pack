/*!
  * \file    mstn_pwm.h
  * \author  Intec Group
  * \version V2.0.0
  * \date    20/10/2016
  * \brief   This file contains all the required functions prototypes for the MSTN PWM firmware library.
  *
  * \warning THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, INTEC SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * \copyright COPYRIGHT 2017 Intec Group
  */

#ifndef __mstn_pwm_h
#define __mstn_pwm_h

/*!
 * Для реализации аппаратного ШИМ в библиотеке MSTN используются таймеры MDR_TIMER2 и MDR_TIMER3
 * контроллера. Таймер MDR_TIMER1 не задействован в библиотеке и может быть использован по усмотрению пользователя.
 * Для упрощения задействования первого таймера в библиотеку MSTN включен модуль "MDR32F9Qx_timer" стандартной библиотеки MDR.
 */

#include "mstn_types.h"

#ifdef __cplusplus
extern "C" {
#endif

typedef enum{
    PWMFREQ_1HZ = 0,        //< 0 <= analogValue <= 50000
    PWMFREQ_ONE_SHOT = 1,   //< 0 <= analogValue <= 65534, 1 = 1usec, 65534 = 0.065534sec, UserInterrupt to Timer2 and External interrupts not available.
    PWMFREQ_50HZ = 2,       //< 0 <= analogValue <= 50000
    PWMFREQ_500HZ = 3,      //< 0 <= analogValue <= 10000
    PWMFREQ_1000HZ = 4,     //< 0 <= analogValue <= 10000, default
    PWMFREQ_2000HZ = 5,     //< 0 <= analogValue <= 10000
    PWMFREQ_4000HZ = 6,     //< 0 <= analogValue <= 10000
    PWMFREQ_8000HZ = 7,     //< 0 <= analogValue <= 10000
    PWMFREQ_10000HZ = 8,    //< 0 <= analogValue <= 10000
    PWMFREQ_20000HZ = 9,    //< 0 <= analogValue <= 4000
    PWMFREQ_40000HZ = 10,   //< 0 <= analogValue <= 2000
    PWMFREQ_50000HZ = 11,   //< 0 <= analogValue <= 1600
    PWMFREQ_80000HZ = 12,   //< 0 <= analogValue <= 1000
    PWMFREQ_100000HZ = 13   //< 0 <= analogValue <= 800
}_PWM_Frequency;

/*!
 * \brief   Устанавливает коэффициент заполнения ШИМ на заданном выводе. 
 * \details Если вывод не находится
 *          в режиме ШИМ выхода на момент вызова функции - он будет автоматически переведен
 *          в режим ШИМ выхода (однако последующий вызов GPIO_DigitalWrite()
 *          для этого вывода переведет его в режим DIGITAL_OUT).
 * \param   pinNum: Номер вывода для установки.
 * \param   analogValue: Значение для установки скважности. Для разных значений частоты ШИМ
 *                       этот параметр имеет разный диапазон допустимых значений (см. комментарии блока {}_PWM_Frequency).
 *                       - Пример для частоты ШИМ = PWMFREQ_50HZ:
 *                              -# При analogValue = 0 - коэффициент заполнения = 0%;
 *                              -# При analogValue = 25000 - коэффициент заполнения = 50%;
 *                              -# При analogValue = 50000 - коэффициент заполнения = 100%.
 *                              -# При выходе за допустимый диапазон значений поведение не определено.
 *                       - Пример для частоты ШИМ = PWMFREQ_1000HZ:
 *                              -# При analogValue = 0 - коэффициент заполнения = 0%;
 *                              -# При analogValue = 5000 - коэффициент заполнения = 50%;
 *                              -# При analogValue = 10000 - коэффициент заполнения = 100%.
 *                       - Пример для частоты ШИМ = PWMFREQ_100000HZ:
 *                              -# При analogValue = 0 - коэффициент заполнения = 0%;
 *                              -# При analogValue = 400 - коэффициент заполнения = 50%;
 *                              -# При analogValue = 800 - коэффициент заполнения = 100%.
 *
 *                       Рекомендуется использовать функцию PWM_AnalogWriteInterpolation()
 * \retval Нет
 */
void PWM_AnalogWrite(uint8_t pinNum, int analogValue);

/*!
 * \brief   Устанавливает коэффициент заполнения ШИМ на заданном выводе. 
 * \details Если вывод не находится в режиме ШИМ выхода на момент вызова функции - он будет автоматически переведен
 *          в режим ШИМ выхода (однако последующий вызов GPIO_DigitalWrite()
 *          для этого вывода переведет его в режим DIGITAL_OUT).
 *          Коэффициент заполнения обновится по завершении текущего импульса.
 * \param   pinNum: Номер вывода для установки. Выводы, для которых доступен режим ШИМ отмечены
 *                  символом "~" в документе Pinout.pdf
 * \param  analogValue: Значение для установки скважности. 
 *                       Параметр имеет диапазон допустимых значений от 0 до 0xFFFF.
 *                       \arg При analogValue <= 0x00 - коэффициент заполнения будет равен 0%.
 *                       \arg При analogValue >= 0xFFFF - коэффициент заполнения будет равен 100%.
 * \retval Нет
 */
void PWM_AnalogWriteInterpolation(uint8_t pinNum, int analogValue);

/*!
 * \brief   Конфигурирует частоту ШИМ для таймеров 2 и 3. по умолчанию частота ШИМ = 1000Гц.
 * \warning Внимание! Изменение частоты инициализирует каналы таймеров 2 и 3 как 
 *          ШИМ-каналы. Это значит, что каждое изменение частоты будет деактивировать
 *          внешние прерывания, заданные с помощью функции EINT_AttachExtInt() и
 *          прерывание, заданное функцией TMR2CH4_AttachInterrupt().
 *          Если возникла необходимость в изменении частоты во время работы - необходимо
 *          заново проинициализировать используемые внешние прерывания.
 * \param   freq: Значение для установки частоты ШИМ. 
 *                Этот параметр может быть одним из значений _PWM_Frequency.
 * \retval Нет
 */
void PWM_SetFreq(_PWM_Frequency freq);

/*!
 * \brief   Конфигурирует частоту ШИМ только для таймера 2 (выводы D4, D6, D7)
 *          по умолчанию частота ШИМ = 1000Гц.
 * \warning Внимание! Изменение частоты инициализирует каналы таймера 2 как 
 *          ШИМ-каналы. Это значит, что каждое изменение частоты будет деактивировать
 *          внешние прерывания, заданные с помощью функции EINT_AttachExtInt() для выводов D4, D6, D7 и
 *          прерывание, заданное функцией TMR2CH4_AttachInterrupt().
 *          Если возникла необходимость в изменении частоты во время работы - необходимо
 *          заново проинициализировать используемые внешние прерывания.
 * \param   freq: Значение для установки частоты ШИМ. 
 *                Этот параметр может быть одним из значений _PWM_Frequency.
 * \retval Нет
 */
void PWM_SetFreqTimer2(_PWM_Frequency freq);

/*!
 * \brief   Конфигурирует частоту ШИМ только для таймера 3 (выводы D1, D8, D9, A0)
 *          по умолчанию частота ШИМ = 1000Гц.
 * \warning Внимание! Изменение частоты инициализирует каналы таймера 3 как 
 *          ШИМ-каналы. Это значит, что каждое изменение частоты будет деактивировать
 *          внешние прерывания, заданные с помощью функции EINT_AttachExtInt() для выводов D1, D8, D9.
 *          Если возникла необходимость в изменении частоты во время работы - необходимо
 *          заново проинициализировать используемые внешние прерывания.
 * \param   freq: Значение для установки частоты ШИМ. 
 *                Этот параметр может быть одним из значений _PWM_Frequency.
 * \retval Нет.
 */
void PWM_SetFreqTimer3(_PWM_Frequency freq);

/*!
 * \brief   Устанавливает функцию (обработчик прерывания), которая будет 
 *          вызываться с частотой ШИМ (частота по умолчанию 1кГц, изменяется с помощью
 *          функций PWM_SetFreq() и PWM_SetFreqTimer2()), помноженной на значение factor.
 * \details Данное прерывание имеет приоритет 3.
 *          Данное прерывание вызывается от сигнала четвертого канала Таймера 2,
 *          который не задействован в аппаратном ШИМ.
 * \param   isr: функция для вызова в прерывании.
 * \param   factor: множитель частоты. Может принимать следующие значения:
 *                  \arg 0 - Коэфф-т умножения частоты = 1.
 *                  \arg 1 - Коэфф-т умножения частоты = 1.
 *                  \arg 2 - Коэфф-т умножения частоты = 2.
 *                  \arg 3 - Коэфф-т умножения частоты = 3.
 *                  \arg При передаче неверного значения множителя прерывание не устанавливается.
 * \retval  Нет
 */
void TMR2CH4_AttachInterrupt(void (*isr)(), int factor);

/*!
 * \brief   Отключает обработчик прерывания, заданного функцией TMR2CH4_AttachInterrupt().
 * \param   Нет
 * \retval  Нет
 */
void TMR2CH4_DetachInterrupt( void );

#ifdef __cplusplus
}
#endif

#endif /* __mstn_pwm_h */

