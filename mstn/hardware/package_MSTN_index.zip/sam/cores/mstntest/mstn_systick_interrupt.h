/*!
  * \file    mstn_systick_interrupt.h
  * \author  Intec Group
  * \version V1.0.0
  * \date    20/04/2017
  * \brief   This file contains all the required functions prototypes for the MSTN SYSTICK INTERRUPT firmware library.
  *
  * \warning THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, INTEC SHALL NOT BE HELD LIABLE FOR ANY DIRECT, INDIRECT
  * OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * \copyright COPYRIGHT 2017 Intec Group
  */

#ifndef __mstn_systick_interrupt_h
#define __mstn_systick_interrupt_h

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef void (*sti_interrupt_t)(void);

/*!
 * \brief   Устанавливает период периодического прерывания 
 *          системного таймера (в микросекундах), в контексте 
 *          которого будет вызвана пользовательская функция, 
 *          переданная в функцию STI_AttachInterrupt().
 * \warning Внимание!
 *          1. Для активации вызовов данной функции, необходимо
 *          раскомментировать объявление константы препроцессора 
 *          __MSTN_SYSTICK_USER_INT в файле "startup_mstn_MDR32F9Qx.s".
 *          2. Дискретность системного таймера будет понижена,
 *          следовательно точность отсчета функций Delay(),
 *          DelayMicroseconds() и GPIO_PulseIn() будет так же 
 *          понижена до периода, заданного в этой функции (в мкс).
 * \param   us - период вызова пользовательского прерывания в мкс.
 *               Должен быть не менее 5 и не более 200000. 
 *               В случае выхода за допустимые пределы - прерывание не установится.
 * \retval  Нет
 */
void STI_SetPeriod_us(uint32_t us);


/*!
 * \brief   Устанавливает период периодического прерывания 
 *          системного таймера (в милисекундах), в контексте 
 *          которого будет вызвана пользовательская функция, 
 *          переданная в функцию STI_AttachInterrupt().
 * \warning Внимание!
 *          1. Для активации вызовов данной функции, необходимо
 *          раскомментировать объявление константы препроцессора 
 *          __MSTN_SYSTICK_USER_INT в файлу "startup_mstn_MDR32F9Qx.s".
 *          2. Дискретность системного таймера будет понижена,
 *          следовательно точность отсчета функций Delay(),
 *          DelayMicroseconds() и GPIO_PulseIn() будет так же 
 *          понижена до периода, заданного в этой функции (в мс).
 * \param   ms - период вызова пользовательского прерывания в мс.
 *               Должен быть не менее 1 и не более 200. 
 *               В случае выхода за допустимые пределы - прерывание не установится.
 * \retval  Нет
 */
void STI_SetPeriod_ms(uint32_t ms);


/*!
 * \brief   Устанавливает функцию для вызова в периодическом
 *          прерывании системного таймера.
 * \warning Внимание!
 *          1. Для активации вызовов данной функции, необходимо
 *          раскомментировать объявление константы препроцессора 
 *          __MSTN_SYSTICK_USER_INT в файлу "startup_mstn_MDR32F9Qx.s".
 *          2. Старайтесь как можно более сократить время выполнения
 *          передаваемой функции. Передаваемая функция будет 
 *          исполняться с наивысшим приоритетом и при долгом
 *          выполнении может повлиять на взаимодействие платы с ПК по
 *          интерфейсу USB.
 *          3. Не используйте в передаваемой функции:
 *          printf, scanf, COM_print, COM_printf, UART_wait,
 *          GPIO_PulseIn и другие ожидающие функции и функции 
 *          работы с интерфейсом USB.
 *                                
 * \param   sti_interrupt - пользовательская функция для вызова в прерывании.
 * \retval  Нет
 */
void STI_AttachInterrupt(sti_interrupt_t sti_interrupt);


/*!
 * \brief   Деактивирует вызов пользовательской функции,
 *          установленной с помощью функции STI_AttachInterrupt().
 * \details Дискретность таймера возвращается к 5мкс.
 * \param   Нет
 * \retval  Нет
 */
void STI_DetachInterrupt(void);

#ifdef __cplusplus
}
#endif

#endif /* __mstn_systick_interrupt_h */

